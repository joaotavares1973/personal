/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH001_J_OPERACOES_SEQ_ROLAGEM")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findAll", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t"),
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findByCdContratoHdr", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t WHERE t.cdContratoHdr = :cdContratoHdr"),
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findByCdFixacaoTipo", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t WHERE t.cdFixacaoTipo = :cdFixacaoTipo"),
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findByCdFixacaoContrato", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t WHERE t.cdFixacaoContrato = :cdFixacaoContrato"),
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findByCdGrpProduto", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findByFlTipoMercado", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t WHERE t.flTipoMercado = :flTipoMercado"),
    @NamedQuery(name = "Tth001JOperacoesSeqRolagem.findByProxSequencia", query = "SELECT t FROM Tth001JOperacoesSeqRolagem t WHERE t.proxSequencia = :proxSequencia")})
public class Tth001JOperacoesSeqRolagem implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_CONTRATO_HDR")
    private long cdContratoHdr;
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_TIPO")
    private BigInteger cdFixacaoTipo;
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_CONTRATO")
    private BigInteger cdFixacaoContrato;
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Column(name = "FL_TIPO_MERCADO")
    private String flTipoMercado;
    @Column(name = "PROX_SEQUENCIA")
    private BigInteger proxSequencia;

    public Tth001JOperacoesSeqRolagem() {
    }

    public long getCdContratoHdr() {
        return cdContratoHdr;
    }

    public void setCdContratoHdr(long cdContratoHdr) {
        this.cdContratoHdr = cdContratoHdr;
    }

    public BigInteger getCdFixacaoTipo() {
        return cdFixacaoTipo;
    }

    public void setCdFixacaoTipo(BigInteger cdFixacaoTipo) {
        this.cdFixacaoTipo = cdFixacaoTipo;
    }

    public BigInteger getCdFixacaoContrato() {
        return cdFixacaoContrato;
    }

    public void setCdFixacaoContrato(BigInteger cdFixacaoContrato) {
        this.cdFixacaoContrato = cdFixacaoContrato;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getFlTipoMercado() {
        return flTipoMercado;
    }

    public void setFlTipoMercado(String flTipoMercado) {
        this.flTipoMercado = flTipoMercado;
    }

    public BigInteger getProxSequencia() {
        return proxSequencia;
    }

    public void setProxSequencia(BigInteger proxSequencia) {
        this.proxSequencia = proxSequencia;
    }
    
}
