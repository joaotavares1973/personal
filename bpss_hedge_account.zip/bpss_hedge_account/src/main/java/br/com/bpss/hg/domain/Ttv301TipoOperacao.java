/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV301_TIPO_OPERACAO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv301TipoOperacao.findAll", query = "SELECT t FROM Ttv301TipoOperacao t"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByFlTipoFixacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.flTipoFixacao = :flTipoFixacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByFlCategoria", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.flCategoria = :flCategoria"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByFlTipoOperacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.flTipoOperacao = :flTipoOperacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByDsTipoOperacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.dsTipoOperacao = :dsTipoOperacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByCdTipoOperacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.cdTipoOperacao = :cdTipoOperacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByCdEmbalagem", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.cdEmbalagem = :cdEmbalagem"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByDtAtualizacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.dtAtualizacao = :dtAtualizacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByDtCriacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.dtCriacao = :dtCriacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByCdUsuarioManutencao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.cdUsuarioManutencao = :cdUsuarioManutencao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByCdCentroLucroComprador", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.cdCentroLucroComprador = :cdCentroLucroComprador"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByCdCentroLucroVendedor", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.cdCentroLucroVendedor = :cdCentroLucroVendedor"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByFlCategoriaOperacao", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.flCategoriaOperacao = :flCategoriaOperacao"),
    @NamedQuery(name = "Ttv301TipoOperacao.findByFlTipoProcessamento", query = "SELECT t FROM Ttv301TipoOperacao t WHERE t.flTipoProcessamento = :flTipoProcessamento")})
public class Ttv301TipoOperacao implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "FL_TIPO_FIXACAO")
    private Character flTipoFixacao;
    @Column(name = "FL_CATEGORIA")
    private Character flCategoria;
    @Basic(optional = false)
    @Column(name = "FL_TIPO_OPERACAO")
    private Character flTipoOperacao;
    @Basic(optional = false)
    @Column(name = "DS_TIPO_OPERACAO")
    private String dsTipoOperacao;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "CD_TIPO_OPERACAO")
    private BigDecimal cdTipoOperacao;
    @Column(name = "CD_EMBALAGEM")
    private String cdEmbalagem;
    @Column(name = "DT_ATUALIZACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtAtualizacao;
    @Column(name = "DT_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtCriacao;
    @Column(name = "CD_USUARIO_MANUTENCAO")
    private String cdUsuarioManutencao;
    @Column(name = "CD_CENTRO_LUCRO_COMPRADOR")
    private BigInteger cdCentroLucroComprador;
    @Column(name = "CD_CENTRO_LUCRO_VENDEDOR")
    private BigInteger cdCentroLucroVendedor;
    @Column(name = "FL_CATEGORIA_OPERACAO")
    private Character flCategoriaOperacao;
    @Column(name = "FL_TIPO_PROCESSAMENTO")
    private Character flTipoProcessamento;

    public Ttv301TipoOperacao() {
    }

    public Ttv301TipoOperacao(BigDecimal cdTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
    }

    public Ttv301TipoOperacao(BigDecimal cdTipoOperacao, Character flTipoOperacao, String dsTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
        this.flTipoOperacao = flTipoOperacao;
        this.dsTipoOperacao = dsTipoOperacao;
    }

    public Character getFlTipoFixacao() {
        return flTipoFixacao;
    }

    public void setFlTipoFixacao(Character flTipoFixacao) {
        this.flTipoFixacao = flTipoFixacao;
    }

    public Character getFlCategoria() {
        return flCategoria;
    }

    public void setFlCategoria(Character flCategoria) {
        this.flCategoria = flCategoria;
    }

    public Character getFlTipoOperacao() {
        return flTipoOperacao;
    }

    public void setFlTipoOperacao(Character flTipoOperacao) {
        this.flTipoOperacao = flTipoOperacao;
    }

    public String getDsTipoOperacao() {
        return dsTipoOperacao;
    }

    public void setDsTipoOperacao(String dsTipoOperacao) {
        this.dsTipoOperacao = dsTipoOperacao;
    }

    public BigDecimal getCdTipoOperacao() {
        return cdTipoOperacao;
    }

    public void setCdTipoOperacao(BigDecimal cdTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
    }

    public String getCdEmbalagem() {
        return cdEmbalagem;
    }

    public void setCdEmbalagem(String cdEmbalagem) {
        this.cdEmbalagem = cdEmbalagem;
    }

    public Date getDtAtualizacao() {
        return dtAtualizacao;
    }

    public void setDtAtualizacao(Date dtAtualizacao) {
        this.dtAtualizacao = dtAtualizacao;
    }

    public Date getDtCriacao() {
        return dtCriacao;
    }

    public void setDtCriacao(Date dtCriacao) {
        this.dtCriacao = dtCriacao;
    }

    public String getCdUsuarioManutencao() {
        return cdUsuarioManutencao;
    }

    public void setCdUsuarioManutencao(String cdUsuarioManutencao) {
        this.cdUsuarioManutencao = cdUsuarioManutencao;
    }

    public BigInteger getCdCentroLucroComprador() {
        return cdCentroLucroComprador;
    }

    public void setCdCentroLucroComprador(BigInteger cdCentroLucroComprador) {
        this.cdCentroLucroComprador = cdCentroLucroComprador;
    }

    public BigInteger getCdCentroLucroVendedor() {
        return cdCentroLucroVendedor;
    }

    public void setCdCentroLucroVendedor(BigInteger cdCentroLucroVendedor) {
        this.cdCentroLucroVendedor = cdCentroLucroVendedor;
    }

    public Character getFlCategoriaOperacao() {
        return flCategoriaOperacao;
    }

    public void setFlCategoriaOperacao(Character flCategoriaOperacao) {
        this.flCategoriaOperacao = flCategoriaOperacao;
    }

    public Character getFlTipoProcessamento() {
        return flTipoProcessamento;
    }

    public void setFlTipoProcessamento(Character flTipoProcessamento) {
        this.flTipoProcessamento = flTipoProcessamento;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdTipoOperacao != null ? cdTipoOperacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ttv301TipoOperacao)) {
            return false;
        }
        Ttv301TipoOperacao other = (Ttv301TipoOperacao) object;
        if ((this.cdTipoOperacao == null && other.cdTipoOperacao != null) || (this.cdTipoOperacao != null && !this.cdTipoOperacao.equals(other.cdTipoOperacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Ttv301TipoOperacao[ cdTipoOperacao=" + cdTipoOperacao + " ]";
    }
    
}
