/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA309_FUNCAO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta309Funcao.findAll", query = "SELECT t FROM Tta309Funcao t"),
    @NamedQuery(name = "Tta309Funcao.findByCdFuncao", query = "SELECT t FROM Tta309Funcao t WHERE t.cdFuncao = :cdFuncao"),
    @NamedQuery(name = "Tta309Funcao.findByNomeFuncao", query = "SELECT t FROM Tta309Funcao t WHERE t.nomeFuncao = :nomeFuncao")})
public class Tta309Funcao implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_FUNCAO")
    private Short cdFuncao;
    @Column(name = "NOME_FUNCAO")
    private String nomeFuncao;
    @OneToMany(mappedBy = "cdFuncao")
    private Collection<Tta411Permissao> tta411PermissaoCollection;

    public Tta309Funcao() {
    }

    public Tta309Funcao(Short cdFuncao) {
        this.cdFuncao = cdFuncao;
    }

    public Short getCdFuncao() {
        return cdFuncao;
    }

    public void setCdFuncao(Short cdFuncao) {
        this.cdFuncao = cdFuncao;
    }

    public String getNomeFuncao() {
        return nomeFuncao;
    }

    public void setNomeFuncao(String nomeFuncao) {
        this.nomeFuncao = nomeFuncao;
    }

    @XmlTransient
    public Collection<Tta411Permissao> getTta411PermissaoCollection() {
        return tta411PermissaoCollection;
    }

    public void setTta411PermissaoCollection(Collection<Tta411Permissao> tta411PermissaoCollection) {
        this.tta411PermissaoCollection = tta411PermissaoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdFuncao != null ? cdFuncao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta309Funcao)) {
            return false;
        }
        Tta309Funcao other = (Tta309Funcao) object;
        if ((this.cdFuncao == null && other.cdFuncao != null) || (this.cdFuncao != null && !this.cdFuncao.equals(other.cdFuncao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta309Funcao[ cdFuncao=" + cdFuncao + " ]";
    }
    
}
