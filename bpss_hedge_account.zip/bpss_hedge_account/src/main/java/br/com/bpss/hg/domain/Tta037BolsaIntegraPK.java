/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class Tta037BolsaIntegraPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "CD_INTEGRA_BOLSA")
    private String cdIntegraBolsa;
    @Basic(optional = false)
    @Column(name = "CD_PARAMETRO_SUP_PROD")
    private short cdParametroSupProd;
    @Basic(optional = false)
    @Column(name = "CD_PARAMETRO_INF_PROD")
    private int cdParametroInfProd;

    public Tta037BolsaIntegraPK() {
    }

    public Tta037BolsaIntegraPK(String cdIntegraBolsa, short cdParametroSupProd, int cdParametroInfProd) {
        this.cdIntegraBolsa = cdIntegraBolsa;
        this.cdParametroSupProd = cdParametroSupProd;
        this.cdParametroInfProd = cdParametroInfProd;
    }

    public String getCdIntegraBolsa() {
        return cdIntegraBolsa;
    }

    public void setCdIntegraBolsa(String cdIntegraBolsa) {
        this.cdIntegraBolsa = cdIntegraBolsa;
    }

    public short getCdParametroSupProd() {
        return cdParametroSupProd;
    }

    public void setCdParametroSupProd(short cdParametroSupProd) {
        this.cdParametroSupProd = cdParametroSupProd;
    }

    public int getCdParametroInfProd() {
        return cdParametroInfProd;
    }

    public void setCdParametroInfProd(int cdParametroInfProd) {
        this.cdParametroInfProd = cdParametroInfProd;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdIntegraBolsa != null ? cdIntegraBolsa.hashCode() : 0);
        hash += (int) cdParametroSupProd;
        hash += (int) cdParametroInfProd;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta037BolsaIntegraPK)) {
            return false;
        }
        Tta037BolsaIntegraPK other = (Tta037BolsaIntegraPK) object;
        if ((this.cdIntegraBolsa == null && other.cdIntegraBolsa != null) || (this.cdIntegraBolsa != null && !this.cdIntegraBolsa.equals(other.cdIntegraBolsa))) {
            return false;
        }
        if (this.cdParametroSupProd != other.cdParametroSupProd) {
            return false;
        }
        if (this.cdParametroInfProd != other.cdParametroInfProd) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta037BolsaIntegraPK[ cdIntegraBolsa=" + cdIntegraBolsa + ", cdParametroSupProd=" + cdParametroSupProd + ", cdParametroInfProd=" + cdParametroInfProd + " ]";
    }
    
}
