/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV304_VALORES_MERCADO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv304ValoresMercado.findAll", query = "SELECT t FROM Ttv304ValoresMercado t"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByDtRef", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.dtRef = :dtRef"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByCdTipoInstrumento", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.cdTipoInstrumento = :cdTipoInstrumento"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByCdGrpProduto", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByCdBolsa", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.cdBolsa = :cdBolsa"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByCdLocalEmbarque", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.cdLocalEmbarque = :cdLocalEmbarque"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByAnoMes", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.anoMes = :anoMes"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByDtFutura", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.ttv304ValoresMercadoPK.dtFutura = :dtFutura"),
    @NamedQuery(name = "Ttv304ValoresMercado.findByVlrMerc", query = "SELECT t FROM Ttv304ValoresMercado t WHERE t.vlrMerc = :vlrMerc")})
public class Ttv304ValoresMercado implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Ttv304ValoresMercadoPK ttv304ValoresMercadoPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "VLR_MERC")
    private BigDecimal vlrMerc;
    @JoinColumn(name = "CD_TIPO_INSTRUMENTO", referencedColumnName = "CD_TIPO_INSTRUMENTO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Ttv303TipoInstrumento ttv303TipoInstrumento;
    @JoinColumn(name = "CD_LOCAL_EMBARQUE", referencedColumnName = "CD_LOCAL_EMBARQUE", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta130LocalEmbarque tta130LocalEmbarque;
    @JoinColumn(name = "CD_GRP_PRODUTO", referencedColumnName = "CD_GRP_PRODUTO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta110GrpProduto tta110GrpProduto;
    @JoinColumn(name = "CD_BOLSA", referencedColumnName = "CD_BOLSA", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta020Bolsa tta020Bolsa;

    public Ttv304ValoresMercado() {
    }

    public Ttv304ValoresMercado(Ttv304ValoresMercadoPK ttv304ValoresMercadoPK) {
        this.ttv304ValoresMercadoPK = ttv304ValoresMercadoPK;
    }

    public Ttv304ValoresMercado(Date dtRef, BigInteger cdTipoInstrumento, BigInteger cdGrpProduto, BigInteger cdBolsa, int cdLocalEmbarque, String anoMes, Date dtFutura) {
        this.ttv304ValoresMercadoPK = new Ttv304ValoresMercadoPK(dtRef, cdTipoInstrumento, cdGrpProduto, cdBolsa, cdLocalEmbarque, anoMes, dtFutura);
    }

    public Ttv304ValoresMercadoPK getTtv304ValoresMercadoPK() {
        return ttv304ValoresMercadoPK;
    }

    public void setTtv304ValoresMercadoPK(Ttv304ValoresMercadoPK ttv304ValoresMercadoPK) {
        this.ttv304ValoresMercadoPK = ttv304ValoresMercadoPK;
    }

    public BigDecimal getVlrMerc() {
        return vlrMerc;
    }

    public void setVlrMerc(BigDecimal vlrMerc) {
        this.vlrMerc = vlrMerc;
    }

    public Ttv303TipoInstrumento getTtv303TipoInstrumento() {
        return ttv303TipoInstrumento;
    }

    public void setTtv303TipoInstrumento(Ttv303TipoInstrumento ttv303TipoInstrumento) {
        this.ttv303TipoInstrumento = ttv303TipoInstrumento;
    }

    public Tta130LocalEmbarque getTta130LocalEmbarque() {
        return tta130LocalEmbarque;
    }

    public void setTta130LocalEmbarque(Tta130LocalEmbarque tta130LocalEmbarque) {
        this.tta130LocalEmbarque = tta130LocalEmbarque;
    }

    public Tta110GrpProduto getTta110GrpProduto() {
        return tta110GrpProduto;
    }

    public void setTta110GrpProduto(Tta110GrpProduto tta110GrpProduto) {
        this.tta110GrpProduto = tta110GrpProduto;
    }

    public Tta020Bolsa getTta020Bolsa() {
        return tta020Bolsa;
    }

    public void setTta020Bolsa(Tta020Bolsa tta020Bolsa) {
        this.tta020Bolsa = tta020Bolsa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ttv304ValoresMercadoPK != null ? ttv304ValoresMercadoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ttv304ValoresMercado)) {
            return false;
        }
        Ttv304ValoresMercado other = (Ttv304ValoresMercado) object;
        if ((this.ttv304ValoresMercadoPK == null && other.ttv304ValoresMercadoPK != null) || (this.ttv304ValoresMercadoPK != null && !this.ttv304ValoresMercadoPK.equals(other.ttv304ValoresMercadoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Ttv304ValoresMercado[ ttv304ValoresMercadoPK=" + ttv304ValoresMercadoPK + " ]";
    }
    
}
