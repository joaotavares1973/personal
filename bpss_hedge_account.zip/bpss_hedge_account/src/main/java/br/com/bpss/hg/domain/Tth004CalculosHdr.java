/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH004_CALCULOS_HDR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth004CalculosHdr.findAll", query = "SELECT t FROM Tth004CalculosHdr t"),
    @NamedQuery(name = "Tth004CalculosHdr.findByCdCalculo", query = "SELECT t FROM Tth004CalculosHdr t WHERE t.cdCalculo = :cdCalculo"),
    @NamedQuery(name = "Tth004CalculosHdr.findByAnoMes", query = "SELECT t FROM Tth004CalculosHdr t WHERE t.anoMes = :anoMes"),
    @NamedQuery(name = "Tth004CalculosHdr.findByCdTipoInstrumento", query = "SELECT t FROM Tth004CalculosHdr t WHERE t.cdTipoInstrumento = :cdTipoInstrumento"),
    @NamedQuery(name = "Tth004CalculosHdr.findByDhSysInsercao", query = "SELECT t FROM Tth004CalculosHdr t WHERE t.dhSysInsercao = :dhSysInsercao"),
    @NamedQuery(name = "Tth004CalculosHdr.findByCdUsuarioInsercao", query = "SELECT t FROM Tth004CalculosHdr t WHERE t.cdUsuarioInsercao = :cdUsuarioInsercao")})
public class Tth004CalculosHdr implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_CALCULO")
    private Long cdCalculo;
    @Column(name = "ANO_MES")
    private String anoMes;
    @Column(name = "CD_TIPO_INSTRUMENTO")
    private BigInteger cdTipoInstrumento;
    @Column(name = "DH_SYS_INSERCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysInsercao;
    @Column(name = "CD_USUARIO_INSERCAO")
    private String cdUsuarioInsercao;

    public Tth004CalculosHdr() {
    }

    public Tth004CalculosHdr(Long cdCalculo) {
        this.cdCalculo = cdCalculo;
    }

    public Long getCdCalculo() {
        return cdCalculo;
    }

    public void setCdCalculo(Long cdCalculo) {
        this.cdCalculo = cdCalculo;
    }

    public String getAnoMes() {
        return anoMes;
    }

    public void setAnoMes(String anoMes) {
        this.anoMes = anoMes;
    }

    public BigInteger getCdTipoInstrumento() {
        return cdTipoInstrumento;
    }

    public void setCdTipoInstrumento(BigInteger cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    public Date getDhSysInsercao() {
        return dhSysInsercao;
    }

    public void setDhSysInsercao(Date dhSysInsercao) {
        this.dhSysInsercao = dhSysInsercao;
    }

    public String getCdUsuarioInsercao() {
        return cdUsuarioInsercao;
    }

    public void setCdUsuarioInsercao(String cdUsuarioInsercao) {
        this.cdUsuarioInsercao = cdUsuarioInsercao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdCalculo != null ? cdCalculo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tth004CalculosHdr)) {
            return false;
        }
        Tth004CalculosHdr other = (Tth004CalculosHdr) object;
        if ((this.cdCalculo == null && other.cdCalculo != null) || (this.cdCalculo != null && !this.cdCalculo.equals(other.cdCalculo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tth004CalculosHdr[ cdCalculo=" + cdCalculo + " ]";
    }
    
}
