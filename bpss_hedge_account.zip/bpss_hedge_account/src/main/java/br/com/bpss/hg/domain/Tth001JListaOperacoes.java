/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH001_J_LISTA_OPERACOES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth001JListaOperacoes.findAll", query = "SELECT t FROM Tth001JListaOperacoes t"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByContrato", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.contrato = :contrato"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByTipoInstrumento", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.tipoInstrumento = :tipoInstrumento"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByNmFixacaoTipo", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.nmFixacaoTipo = :nmFixacaoTipo"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByCdGrpProduto", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByNmGrpProduto", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.nmGrpProduto = :nmGrpProduto"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByCdTipoOperacao", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.cdTipoOperacao = :cdTipoOperacao"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByDsTipoOperacao", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.dsTipoOperacao = :dsTipoOperacao"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByDtNegociacao", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.dtNegociacao = :dtNegociacao"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByAnoSafra", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.anoSafra = :anoSafra"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByMesAno", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.mesAno = :mesAno"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByQtde", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.qtde = :qtde"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByPreco", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.preco = :preco"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByStatus", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.status = :status"),
    @NamedQuery(name = "Tth001JListaOperacoes.findByCdOperacao", query = "SELECT t FROM Tth001JListaOperacoes t WHERE t.cdOperacao = :cdOperacao")})
public class Tth001JListaOperacoes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CONTRATO")
    private long contrato;
    @Column(name = "TIPO_INSTRUMENTO")
    private BigInteger tipoInstrumento;
    @Basic(optional = false)
    @Column(name = "NM_FIXACAO_TIPO")
    private String nmFixacaoTipo;
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "NM_GRP_PRODUTO")
    private String nmGrpProduto;
    @Column(name = "CD_TIPO_OPERACAO")
    private BigInteger cdTipoOperacao;
    @Basic(optional = false)
    @Column(name = "DS_TIPO_OPERACAO")
    private String dsTipoOperacao;
    @Column(name = "DT_NEGOCIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtNegociacao;
    @Column(name = "ANO_SAFRA")
    private String anoSafra;
    @Column(name = "MES_ANO")
    private String mesAno;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "QTDE")
    private BigDecimal qtde;
    @Column(name = "PRECO")
    private BigDecimal preco;
    @Column(name = "STATUS")
    private Character status;
    @Basic(optional = false)
    @Column(name = "CD_OPERACAO")
    private long cdOperacao;

    public Tth001JListaOperacoes() {
    }

    public long getContrato() {
        return contrato;
    }

    public void setContrato(long contrato) {
        this.contrato = contrato;
    }

    public BigInteger getTipoInstrumento() {
        return tipoInstrumento;
    }

    public void setTipoInstrumento(BigInteger tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }

    public String getNmFixacaoTipo() {
        return nmFixacaoTipo;
    }

    public void setNmFixacaoTipo(String nmFixacaoTipo) {
        this.nmFixacaoTipo = nmFixacaoTipo;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getNmGrpProduto() {
        return nmGrpProduto;
    }

    public void setNmGrpProduto(String nmGrpProduto) {
        this.nmGrpProduto = nmGrpProduto;
    }

    public BigInteger getCdTipoOperacao() {
        return cdTipoOperacao;
    }

    public void setCdTipoOperacao(BigInteger cdTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
    }

    public String getDsTipoOperacao() {
        return dsTipoOperacao;
    }

    public void setDsTipoOperacao(String dsTipoOperacao) {
        this.dsTipoOperacao = dsTipoOperacao;
    }

    public Date getDtNegociacao() {
        return dtNegociacao;
    }

    public void setDtNegociacao(Date dtNegociacao) {
        this.dtNegociacao = dtNegociacao;
    }

    public String getAnoSafra() {
        return anoSafra;
    }

    public void setAnoSafra(String anoSafra) {
        this.anoSafra = anoSafra;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public BigDecimal getQtde() {
        return qtde;
    }

    public void setQtde(BigDecimal qtde) {
        this.qtde = qtde;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public long getCdOperacao() {
        return cdOperacao;
    }

    public void setCdOperacao(long cdOperacao) {
        this.cdOperacao = cdOperacao;
    }
    
}
