/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA402_USUARIO_CENTRO_LUCRO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta402UsuarioCentroLucro.findAll", query = "SELECT t FROM Tta402UsuarioCentroLucro t"),
    @NamedQuery(name = "Tta402UsuarioCentroLucro.findByCdUsuario", query = "SELECT t FROM Tta402UsuarioCentroLucro t WHERE t.tta402UsuarioCentroLucroPK.cdUsuario = :cdUsuario"),
    @NamedQuery(name = "Tta402UsuarioCentroLucro.findByCdCentroLucro", query = "SELECT t FROM Tta402UsuarioCentroLucro t WHERE t.tta402UsuarioCentroLucroPK.cdCentroLucro = :cdCentroLucro"),
    @NamedQuery(name = "Tta402UsuarioCentroLucro.findByFlAtualizaVlMercado", query = "SELECT t FROM Tta402UsuarioCentroLucro t WHERE t.flAtualizaVlMercado = :flAtualizaVlMercado"),
    @NamedQuery(name = "Tta402UsuarioCentroLucro.findByCdUsuarioManutencao", query = "SELECT t FROM Tta402UsuarioCentroLucro t WHERE t.cdUsuarioManutencao = :cdUsuarioManutencao"),
    @NamedQuery(name = "Tta402UsuarioCentroLucro.findByDhSysManutencao", query = "SELECT t FROM Tta402UsuarioCentroLucro t WHERE t.dhSysManutencao = :dhSysManutencao")})
public class Tta402UsuarioCentroLucro implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tta402UsuarioCentroLucroPK tta402UsuarioCentroLucroPK;
    @Basic(optional = false)
    @Column(name = "FL_ATUALIZA_VL_MERCADO")
    private Character flAtualizaVlMercado;
    @Basic(optional = false)
    @Column(name = "CD_USUARIO_MANUTENCAO")
    private String cdUsuarioManutencao;
    @Basic(optional = false)
    @Column(name = "DH_SYS_MANUTENCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysManutencao;
    @JoinColumn(name = "CD_USUARIO", referencedColumnName = "CD_USUARIO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta401Usuario tta401Usuario;

    public Tta402UsuarioCentroLucro() {
    }

    public Tta402UsuarioCentroLucro(Tta402UsuarioCentroLucroPK tta402UsuarioCentroLucroPK) {
        this.tta402UsuarioCentroLucroPK = tta402UsuarioCentroLucroPK;
    }

    public Tta402UsuarioCentroLucro(Tta402UsuarioCentroLucroPK tta402UsuarioCentroLucroPK, Character flAtualizaVlMercado, String cdUsuarioManutencao, Date dhSysManutencao) {
        this.tta402UsuarioCentroLucroPK = tta402UsuarioCentroLucroPK;
        this.flAtualizaVlMercado = flAtualizaVlMercado;
        this.cdUsuarioManutencao = cdUsuarioManutencao;
        this.dhSysManutencao = dhSysManutencao;
    }

    public Tta402UsuarioCentroLucro(String cdUsuario, BigInteger cdCentroLucro) {
        this.tta402UsuarioCentroLucroPK = new Tta402UsuarioCentroLucroPK(cdUsuario, cdCentroLucro);
    }

    public Tta402UsuarioCentroLucroPK getTta402UsuarioCentroLucroPK() {
        return tta402UsuarioCentroLucroPK;
    }

    public void setTta402UsuarioCentroLucroPK(Tta402UsuarioCentroLucroPK tta402UsuarioCentroLucroPK) {
        this.tta402UsuarioCentroLucroPK = tta402UsuarioCentroLucroPK;
    }

    public Character getFlAtualizaVlMercado() {
        return flAtualizaVlMercado;
    }

    public void setFlAtualizaVlMercado(Character flAtualizaVlMercado) {
        this.flAtualizaVlMercado = flAtualizaVlMercado;
    }

    public String getCdUsuarioManutencao() {
        return cdUsuarioManutencao;
    }

    public void setCdUsuarioManutencao(String cdUsuarioManutencao) {
        this.cdUsuarioManutencao = cdUsuarioManutencao;
    }

    public Date getDhSysManutencao() {
        return dhSysManutencao;
    }

    public void setDhSysManutencao(Date dhSysManutencao) {
        this.dhSysManutencao = dhSysManutencao;
    }

    public Tta401Usuario getTta401Usuario() {
        return tta401Usuario;
    }

    public void setTta401Usuario(Tta401Usuario tta401Usuario) {
        this.tta401Usuario = tta401Usuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tta402UsuarioCentroLucroPK != null ? tta402UsuarioCentroLucroPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta402UsuarioCentroLucro)) {
            return false;
        }
        Tta402UsuarioCentroLucro other = (Tta402UsuarioCentroLucro) object;
        if ((this.tta402UsuarioCentroLucroPK == null && other.tta402UsuarioCentroLucroPK != null) || (this.tta402UsuarioCentroLucroPK != null && !this.tta402UsuarioCentroLucroPK.equals(other.tta402UsuarioCentroLucroPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta402UsuarioCentroLucro[ tta402UsuarioCentroLucroPK=" + tta402UsuarioCentroLucroPK + " ]";
    }
    
}
