/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class Tta402UsuarioCentroLucroPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "CD_USUARIO")
    private String cdUsuario;
    @Basic(optional = false)
    @Column(name = "CD_CENTRO_LUCRO")
    private BigInteger cdCentroLucro;

    public Tta402UsuarioCentroLucroPK() {
    }

    public Tta402UsuarioCentroLucroPK(String cdUsuario, BigInteger cdCentroLucro) {
        this.cdUsuario = cdUsuario;
        this.cdCentroLucro = cdCentroLucro;
    }

    public String getCdUsuario() {
        return cdUsuario;
    }

    public void setCdUsuario(String cdUsuario) {
        this.cdUsuario = cdUsuario;
    }

    public BigInteger getCdCentroLucro() {
        return cdCentroLucro;
    }

    public void setCdCentroLucro(BigInteger cdCentroLucro) {
        this.cdCentroLucro = cdCentroLucro;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdUsuario != null ? cdUsuario.hashCode() : 0);
        hash += (cdCentroLucro != null ? cdCentroLucro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta402UsuarioCentroLucroPK)) {
            return false;
        }
        Tta402UsuarioCentroLucroPK other = (Tta402UsuarioCentroLucroPK) object;
        if ((this.cdUsuario == null && other.cdUsuario != null) || (this.cdUsuario != null && !this.cdUsuario.equals(other.cdUsuario))) {
            return false;
        }
        if ((this.cdCentroLucro == null && other.cdCentroLucro != null) || (this.cdCentroLucro != null && !this.cdCentroLucro.equals(other.cdCentroLucro))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta402UsuarioCentroLucroPK[ cdUsuario=" + cdUsuario + ", cdCentroLucro=" + cdCentroLucro + " ]";
    }
    
}
