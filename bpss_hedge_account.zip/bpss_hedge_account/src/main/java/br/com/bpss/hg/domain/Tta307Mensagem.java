/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA307_MENSAGEM")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta307Mensagem.findAll", query = "SELECT t FROM Tta307Mensagem t"),
    @NamedQuery(name = "Tta307Mensagem.findByCdMensagem", query = "SELECT t FROM Tta307Mensagem t WHERE t.cdMensagem = :cdMensagem"),
    @NamedQuery(name = "Tta307Mensagem.findByResumoMsg", query = "SELECT t FROM Tta307Mensagem t WHERE t.resumoMsg = :resumoMsg"),
    @NamedQuery(name = "Tta307Mensagem.findByDetalheMsg", query = "SELECT t FROM Tta307Mensagem t WHERE t.detalheMsg = :detalheMsg"),
    @NamedQuery(name = "Tta307Mensagem.findByCdMsgBpss", query = "SELECT t FROM Tta307Mensagem t WHERE t.cdMsgBpss = :cdMsgBpss")})
public class Tta307Mensagem implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_MENSAGEM")
    private Integer cdMensagem;
    @Column(name = "RESUMO_MSG")
    private String resumoMsg;
    @Column(name = "DETALHE_MSG")
    private String detalheMsg;
    @Basic(optional = false)
    @Column(name = "CD_MSG_BPSS")
    private int cdMsgBpss;

    public Tta307Mensagem() {
    }

    public Tta307Mensagem(Integer cdMensagem) {
        this.cdMensagem = cdMensagem;
    }

    public Tta307Mensagem(Integer cdMensagem, int cdMsgBpss) {
        this.cdMensagem = cdMensagem;
        this.cdMsgBpss = cdMsgBpss;
    }

    public Integer getCdMensagem() {
        return cdMensagem;
    }

    public void setCdMensagem(Integer cdMensagem) {
        this.cdMensagem = cdMensagem;
    }

    public String getResumoMsg() {
        return resumoMsg;
    }

    public void setResumoMsg(String resumoMsg) {
        this.resumoMsg = resumoMsg;
    }

    public String getDetalheMsg() {
        return detalheMsg;
    }

    public void setDetalheMsg(String detalheMsg) {
        this.detalheMsg = detalheMsg;
    }

    public int getCdMsgBpss() {
        return cdMsgBpss;
    }

    public void setCdMsgBpss(int cdMsgBpss) {
        this.cdMsgBpss = cdMsgBpss;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdMensagem != null ? cdMensagem.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta307Mensagem)) {
            return false;
        }
        Tta307Mensagem other = (Tta307Mensagem) object;
        if ((this.cdMensagem == null && other.cdMensagem != null) || (this.cdMensagem != null && !this.cdMensagem.equals(other.cdMensagem))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta307Mensagem[ cdMensagem=" + cdMensagem + " ]";
    }
    
}
