/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV301_J_TIPO_OPERACAO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv301JTipoOperacao.findAll", query = "SELECT t FROM Ttv301JTipoOperacao t"),
    @NamedQuery(name = "Ttv301JTipoOperacao.findByCdTipoOperacao", query = "SELECT t FROM Ttv301JTipoOperacao t WHERE t.cdTipoOperacao = :cdTipoOperacao"),
    @NamedQuery(name = "Ttv301JTipoOperacao.findByDsTipoOperacao", query = "SELECT t FROM Ttv301JTipoOperacao t WHERE t.dsTipoOperacao = :dsTipoOperacao")})
public class Ttv301JTipoOperacao implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_TIPO_OPERACAO")
    private BigInteger cdTipoOperacao;
    @Basic(optional = false)
    @Column(name = "DS_TIPO_OPERACAO")
    private String dsTipoOperacao;

    public Ttv301JTipoOperacao() {
    }

    public BigInteger getCdTipoOperacao() {
        return cdTipoOperacao;
    }

    public void setCdTipoOperacao(BigInteger cdTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
    }

    public String getDsTipoOperacao() {
        return dsTipoOperacao;
    }

    public void setDsTipoOperacao(String dsTipoOperacao) {
        this.dsTipoOperacao = dsTipoOperacao;
    }
    
}
