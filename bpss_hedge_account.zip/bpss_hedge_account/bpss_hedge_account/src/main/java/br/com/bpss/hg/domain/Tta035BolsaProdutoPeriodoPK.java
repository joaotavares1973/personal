/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class Tta035BolsaProdutoPeriodoPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "DS_MES_EMBARQUE")
    private String dsMesEmbarque;

    public Tta035BolsaProdutoPeriodoPK() {
    }

    public Tta035BolsaProdutoPeriodoPK(BigInteger cdGrpProduto, String dsMesEmbarque) {
        this.cdGrpProduto = cdGrpProduto;
        this.dsMesEmbarque = dsMesEmbarque;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getDsMesEmbarque() {
        return dsMesEmbarque;
    }

    public void setDsMesEmbarque(String dsMesEmbarque) {
        this.dsMesEmbarque = dsMesEmbarque;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdGrpProduto != null ? cdGrpProduto.hashCode() : 0);
        hash += (dsMesEmbarque != null ? dsMesEmbarque.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta035BolsaProdutoPeriodoPK)) {
            return false;
        }
        Tta035BolsaProdutoPeriodoPK other = (Tta035BolsaProdutoPeriodoPK) object;
        if ((this.cdGrpProduto == null && other.cdGrpProduto != null) || (this.cdGrpProduto != null && !this.cdGrpProduto.equals(other.cdGrpProduto))) {
            return false;
        }
        if ((this.dsMesEmbarque == null && other.dsMesEmbarque != null) || (this.dsMesEmbarque != null && !this.dsMesEmbarque.equals(other.dsMesEmbarque))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta035BolsaProdutoPeriodoPK[ cdGrpProduto=" + cdGrpProduto + ", dsMesEmbarque=" + dsMesEmbarque + " ]";
    }
    
}
