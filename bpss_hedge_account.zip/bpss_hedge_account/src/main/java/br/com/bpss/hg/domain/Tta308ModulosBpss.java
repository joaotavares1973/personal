/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA308_MODULOS_BPSS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta308ModulosBpss.findAll", query = "SELECT t FROM Tta308ModulosBpss t"),
    @NamedQuery(name = "Tta308ModulosBpss.findByCdModulo", query = "SELECT t FROM Tta308ModulosBpss t WHERE t.cdModulo = :cdModulo"),
    @NamedQuery(name = "Tta308ModulosBpss.findByNomeModulo", query = "SELECT t FROM Tta308ModulosBpss t WHERE t.nomeModulo = :nomeModulo")})
public class Tta308ModulosBpss implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_MODULO")
    private Short cdModulo;
    @Column(name = "NOME_MODULO")
    private String nomeModulo;
    @OneToMany(mappedBy = "cdModulo")
    private Collection<Tta411Permissao> tta411PermissaoCollection;

    public Tta308ModulosBpss() {
    }

    public Tta308ModulosBpss(Short cdModulo) {
        this.cdModulo = cdModulo;
    }

    public Short getCdModulo() {
        return cdModulo;
    }

    public void setCdModulo(Short cdModulo) {
        this.cdModulo = cdModulo;
    }

    public String getNomeModulo() {
        return nomeModulo;
    }

    public void setNomeModulo(String nomeModulo) {
        this.nomeModulo = nomeModulo;
    }

    @XmlTransient
    public Collection<Tta411Permissao> getTta411PermissaoCollection() {
        return tta411PermissaoCollection;
    }

    public void setTta411PermissaoCollection(Collection<Tta411Permissao> tta411PermissaoCollection) {
        this.tta411PermissaoCollection = tta411PermissaoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdModulo != null ? cdModulo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta308ModulosBpss)) {
            return false;
        }
        Tta308ModulosBpss other = (Tta308ModulosBpss) object;
        if ((this.cdModulo == null && other.cdModulo != null) || (this.cdModulo != null && !this.cdModulo.equals(other.cdModulo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta308ModulosBpss[ cdModulo=" + cdModulo + " ]";
    }
    
}
