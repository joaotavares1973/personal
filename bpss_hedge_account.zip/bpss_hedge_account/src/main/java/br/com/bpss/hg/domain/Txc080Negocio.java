/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TXC080_NEGOCIO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Txc080Negocio.findAll", query = "SELECT t FROM Txc080Negocio t"),
    @NamedQuery(name = "Txc080Negocio.findByCdNegocio", query = "SELECT t FROM Txc080Negocio t WHERE t.cdNegocio = :cdNegocio"),
    @NamedQuery(name = "Txc080Negocio.findByDsNegocio", query = "SELECT t FROM Txc080Negocio t WHERE t.dsNegocio = :dsNegocio")})
public class Txc080Negocio implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_NEGOCIO")
    private Short cdNegocio;
    @Column(name = "DS_NEGOCIO")
    private String dsNegocio;

    public Txc080Negocio() {
    }

    public Txc080Negocio(Short cdNegocio) {
        this.cdNegocio = cdNegocio;
    }

    public Short getCdNegocio() {
        return cdNegocio;
    }

    public void setCdNegocio(Short cdNegocio) {
        this.cdNegocio = cdNegocio;
    }

    public String getDsNegocio() {
        return dsNegocio;
    }

    public void setDsNegocio(String dsNegocio) {
        this.dsNegocio = dsNegocio;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdNegocio != null ? cdNegocio.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Txc080Negocio)) {
            return false;
        }
        Txc080Negocio other = (Txc080Negocio) object;
        if ((this.cdNegocio == null && other.cdNegocio != null) || (this.cdNegocio != null && !this.cdNegocio.equals(other.cdNegocio))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Txc080Negocio[ cdNegocio=" + cdNegocio + " ]";
    }
    
}
