/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA104_J_FIXACAO_TIPO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta104JFixacaoTipo.findAll", query = "SELECT t FROM Tta104JFixacaoTipo t"),
    @NamedQuery(name = "Tta104JFixacaoTipo.findByCdFixacaoTipo", query = "SELECT t FROM Tta104JFixacaoTipo t WHERE t.cdFixacaoTipo = :cdFixacaoTipo"),
    @NamedQuery(name = "Tta104JFixacaoTipo.findByNmFixacaoTipo", query = "SELECT t FROM Tta104JFixacaoTipo t WHERE t.nmFixacaoTipo = :nmFixacaoTipo")})
public class Tta104JFixacaoTipo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_TIPO")
    private BigInteger cdFixacaoTipo;
    @Basic(optional = false)
    @Column(name = "NM_FIXACAO_TIPO")
    private String nmFixacaoTipo;

    public Tta104JFixacaoTipo() {
    }

    public BigInteger getCdFixacaoTipo() {
        return cdFixacaoTipo;
    }

    public void setCdFixacaoTipo(BigInteger cdFixacaoTipo) {
        this.cdFixacaoTipo = cdFixacaoTipo;
    }

    public String getNmFixacaoTipo() {
        return nmFixacaoTipo;
    }

    public void setNmFixacaoTipo(String nmFixacaoTipo) {
        this.nmFixacaoTipo = nmFixacaoTipo;
    }
    
}
