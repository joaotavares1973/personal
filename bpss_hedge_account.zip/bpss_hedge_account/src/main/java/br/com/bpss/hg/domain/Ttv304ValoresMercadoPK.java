/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author HP
 */
@Embeddable
public class Ttv304ValoresMercadoPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "DT_REF")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtRef;
    @Basic(optional = false)
    @Column(name = "CD_TIPO_INSTRUMENTO")
    private BigInteger cdTipoInstrumento;
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "CD_BOLSA")
    private BigInteger cdBolsa;
    @Basic(optional = false)
    @Column(name = "CD_LOCAL_EMBARQUE")
    private int cdLocalEmbarque;
    @Basic(optional = false)
    @Column(name = "ANO_MES")
    private String anoMes;
    @Basic(optional = false)
    @Column(name = "DT_FUTURA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtFutura;

    public Ttv304ValoresMercadoPK() {
    }

    public Ttv304ValoresMercadoPK(Date dtRef, BigInteger cdTipoInstrumento, BigInteger cdGrpProduto, BigInteger cdBolsa, int cdLocalEmbarque, String anoMes, Date dtFutura) {
        this.dtRef = dtRef;
        this.cdTipoInstrumento = cdTipoInstrumento;
        this.cdGrpProduto = cdGrpProduto;
        this.cdBolsa = cdBolsa;
        this.cdLocalEmbarque = cdLocalEmbarque;
        this.anoMes = anoMes;
        this.dtFutura = dtFutura;
    }

    public Date getDtRef() {
        return dtRef;
    }

    public void setDtRef(Date dtRef) {
        this.dtRef = dtRef;
    }

    public BigInteger getCdTipoInstrumento() {
        return cdTipoInstrumento;
    }

    public void setCdTipoInstrumento(BigInteger cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public BigInteger getCdBolsa() {
        return cdBolsa;
    }

    public void setCdBolsa(BigInteger cdBolsa) {
        this.cdBolsa = cdBolsa;
    }

    public int getCdLocalEmbarque() {
        return cdLocalEmbarque;
    }

    public void setCdLocalEmbarque(int cdLocalEmbarque) {
        this.cdLocalEmbarque = cdLocalEmbarque;
    }

    public String getAnoMes() {
        return anoMes;
    }

    public void setAnoMes(String anoMes) {
        this.anoMes = anoMes;
    }

    public Date getDtFutura() {
        return dtFutura;
    }

    public void setDtFutura(Date dtFutura) {
        this.dtFutura = dtFutura;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (dtRef != null ? dtRef.hashCode() : 0);
        hash += (cdTipoInstrumento != null ? cdTipoInstrumento.hashCode() : 0);
        hash += (cdGrpProduto != null ? cdGrpProduto.hashCode() : 0);
        hash += (cdBolsa != null ? cdBolsa.hashCode() : 0);
        hash += (int) cdLocalEmbarque;
        hash += (anoMes != null ? anoMes.hashCode() : 0);
        hash += (dtFutura != null ? dtFutura.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ttv304ValoresMercadoPK)) {
            return false;
        }
        Ttv304ValoresMercadoPK other = (Ttv304ValoresMercadoPK) object;
        if ((this.dtRef == null && other.dtRef != null) || (this.dtRef != null && !this.dtRef.equals(other.dtRef))) {
            return false;
        }
        if ((this.cdTipoInstrumento == null && other.cdTipoInstrumento != null) || (this.cdTipoInstrumento != null && !this.cdTipoInstrumento.equals(other.cdTipoInstrumento))) {
            return false;
        }
        if ((this.cdGrpProduto == null && other.cdGrpProduto != null) || (this.cdGrpProduto != null && !this.cdGrpProduto.equals(other.cdGrpProduto))) {
            return false;
        }
        if ((this.cdBolsa == null && other.cdBolsa != null) || (this.cdBolsa != null && !this.cdBolsa.equals(other.cdBolsa))) {
            return false;
        }
        if (this.cdLocalEmbarque != other.cdLocalEmbarque) {
            return false;
        }
        if ((this.anoMes == null && other.anoMes != null) || (this.anoMes != null && !this.anoMes.equals(other.anoMes))) {
            return false;
        }
        if ((this.dtFutura == null && other.dtFutura != null) || (this.dtFutura != null && !this.dtFutura.equals(other.dtFutura))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Ttv304ValoresMercadoPK[ dtRef=" + dtRef + ", cdTipoInstrumento=" + cdTipoInstrumento + ", cdGrpProduto=" + cdGrpProduto + ", cdBolsa=" + cdBolsa + ", cdLocalEmbarque=" + cdLocalEmbarque + ", anoMes=" + anoMes + ", dtFutura=" + dtFutura + " ]";
    }
    
}
