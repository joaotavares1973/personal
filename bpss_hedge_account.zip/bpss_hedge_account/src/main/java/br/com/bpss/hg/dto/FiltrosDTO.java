package br.com.bpss.hg.dto;

public class FiltrosDTO {

	String anoSafra;
	String dtNegociacaoIni;
	String dtNegociacaoFim;

	public String getAnoSafra() {
		return anoSafra;
	}

	public void setAnoSafra(String anoSafra) {
		this.anoSafra = anoSafra;
	}

	public String getDtNegociacaoIni() {
		return dtNegociacaoIni;
	}

	public void setDtNegociacaoIni(String dtNegociacaoIni) {
		this.dtNegociacaoIni = dtNegociacaoIni;
	}

	public String getDtNegociacaoFim() {
		return dtNegociacaoFim;
	}

	public void setDtNegociacaoFim(String dtNegociacaoFim) {
		this.dtNegociacaoFim = dtNegociacaoFim;
	}

}
