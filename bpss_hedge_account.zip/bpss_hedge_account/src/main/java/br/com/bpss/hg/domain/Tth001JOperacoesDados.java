/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH001_J_OPERACOES_DADOS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth001JOperacoesDados.findAll", query = "SELECT t FROM Tth001JOperacoesDados t"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByCdOperacao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.cdOperacao = :cdOperacao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByContrato", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.contrato = :contrato"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByTipoInstrumento", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.tipoInstrumento = :tipoInstrumento"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByComponente", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.componente = :componente"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByCdGrpProduto", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByProduto", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.produto = :produto"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByCdTipoOperacao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.cdTipoOperacao = :cdTipoOperacao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByTipoOperacao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.tipoOperacao = :tipoOperacao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByDtNegociacao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.dtNegociacao = :dtNegociacao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByContratoInterno", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.contratoInterno = :contratoInterno"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByDtExpiracao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.dtExpiracao = :dtExpiracao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByAnoSafra", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.anoSafra = :anoSafra"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByMesAno", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.mesAno = :mesAno"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByCdFixacaoContrato", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.cdFixacaoContrato = :cdFixacaoContrato"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByDtFixacao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.dtFixacao = :dtFixacao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByQtde", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.qtde = :qtde"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByVlrUnit", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.vlrUnit = :vlrUnit"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByVlrSpread", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.vlrSpread = :vlrSpread"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByDesignacao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.designacao = :designacao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByRolagem", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.rolagem = :rolagem"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByMercado", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.mercado = :mercado"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByTipoRegistro", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.tipoRegistro = :tipoRegistro"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByDtInsercao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.dtInsercao = :dtInsercao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByUsuarioInsercao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.usuarioInsercao = :usuarioInsercao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByDtManutencao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.dtManutencao = :dtManutencao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByUsuarioManutencao", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.usuarioManutencao = :usuarioManutencao"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByCdGrpProdutoInst", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.cdGrpProdutoInst = :cdGrpProdutoInst"),
    @NamedQuery(name = "Tth001JOperacoesDados.findByCdOperacaoOriginal", query = "SELECT t FROM Tth001JOperacoesDados t WHERE t.cdOperacaoOriginal = :cdOperacaoOriginal")})
public class Tth001JOperacoesDados implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_OPERACAO")
    private long cdOperacao;
    @Basic(optional = false)
    @Column(name = "CONTRATO")
    private long contrato;
    @Column(name = "TIPO_INSTRUMENTO")
    private BigInteger tipoInstrumento;
    @Basic(optional = false)
    @Column(name = "COMPONENTE")
    private String componente;
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "PRODUTO")
    private String produto;
    @Column(name = "CD_TIPO_OPERACAO")
    private BigInteger cdTipoOperacao;
    @Basic(optional = false)
    @Column(name = "TIPO_OPERACAO")
    private String tipoOperacao;
    @Column(name = "DT_NEGOCIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtNegociacao;
    @Column(name = "CONTRATO_INTERNO")
    private String contratoInterno;
    @Column(name = "DT_EXPIRACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtExpiracao;
    @Column(name = "ANO_SAFRA")
    private String anoSafra;
    @Column(name = "MES_ANO")
    private String mesAno;
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_CONTRATO")
    private BigInteger cdFixacaoContrato;
    @Column(name = "DT_FIXACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtFixacao;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "QTDE")
    private BigDecimal qtde;
    @Column(name = "VLR_UNIT")
    private BigDecimal vlrUnit;
    @Column(name = "VLR_SPREAD")
    private BigDecimal vlrSpread;
    @Column(name = "DESIGNACAO")
    private String designacao;
    @Column(name = "ROLAGEM")
    private String rolagem;
    @Column(name = "MERCADO")
    private String mercado;
    @Column(name = "TIPO_REGISTRO")
    private String tipoRegistro;
    @Column(name = "DT_INSERCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtInsercao;
    @Column(name = "USUARIO_INSERCAO")
    private String usuarioInsercao;
    @Column(name = "DT_MANUTENCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtManutencao;
    @Column(name = "USUARIO_MANUTENCAO")
    private String usuarioManutencao;
    @Column(name = "CD_GRP_PRODUTO_INST")
    private BigInteger cdGrpProdutoInst;
    @Column(name = "CD_OPERACAO_ORIGINAL")
    private Long cdOperacaoOriginal;

    public Tth001JOperacoesDados() {
    }

    public long getCdOperacao() {
        return cdOperacao;
    }

    public void setCdOperacao(long cdOperacao) {
        this.cdOperacao = cdOperacao;
    }

    public long getContrato() {
        return contrato;
    }

    public void setContrato(long contrato) {
        this.contrato = contrato;
    }

    public BigInteger getTipoInstrumento() {
        return tipoInstrumento;
    }

    public void setTipoInstrumento(BigInteger tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }

    public String getComponente() {
        return componente;
    }

    public void setComponente(String componente) {
        this.componente = componente;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public BigInteger getCdTipoOperacao() {
        return cdTipoOperacao;
    }

    public void setCdTipoOperacao(BigInteger cdTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
    }

    public String getTipoOperacao() {
        return tipoOperacao;
    }

    public void setTipoOperacao(String tipoOperacao) {
        this.tipoOperacao = tipoOperacao;
    }

    public Date getDtNegociacao() {
        return dtNegociacao;
    }

    public void setDtNegociacao(Date dtNegociacao) {
        this.dtNegociacao = dtNegociacao;
    }

    public String getContratoInterno() {
        return contratoInterno;
    }

    public void setContratoInterno(String contratoInterno) {
        this.contratoInterno = contratoInterno;
    }

    public Date getDtExpiracao() {
        return dtExpiracao;
    }

    public void setDtExpiracao(Date dtExpiracao) {
        this.dtExpiracao = dtExpiracao;
    }

    public String getAnoSafra() {
        return anoSafra;
    }

    public void setAnoSafra(String anoSafra) {
        this.anoSafra = anoSafra;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public BigInteger getCdFixacaoContrato() {
        return cdFixacaoContrato;
    }

    public void setCdFixacaoContrato(BigInteger cdFixacaoContrato) {
        this.cdFixacaoContrato = cdFixacaoContrato;
    }

    public Date getDtFixacao() {
        return dtFixacao;
    }

    public void setDtFixacao(Date dtFixacao) {
        this.dtFixacao = dtFixacao;
    }

    public BigDecimal getQtde() {
        return qtde;
    }

    public void setQtde(BigDecimal qtde) {
        this.qtde = qtde;
    }

    public BigDecimal getVlrUnit() {
        return vlrUnit;
    }

    public void setVlrUnit(BigDecimal vlrUnit) {
        this.vlrUnit = vlrUnit;
    }

    public BigDecimal getVlrSpread() {
        return vlrSpread;
    }

    public void setVlrSpread(BigDecimal vlrSpread) {
        this.vlrSpread = vlrSpread;
    }

    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    public String getRolagem() {
        return rolagem;
    }

    public void setRolagem(String rolagem) {
        this.rolagem = rolagem;
    }

    public String getMercado() {
        return mercado;
    }

    public void setMercado(String mercado) {
        this.mercado = mercado;
    }

    public String getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(String tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public Date getDtInsercao() {
        return dtInsercao;
    }

    public void setDtInsercao(Date dtInsercao) {
        this.dtInsercao = dtInsercao;
    }

    public String getUsuarioInsercao() {
        return usuarioInsercao;
    }

    public void setUsuarioInsercao(String usuarioInsercao) {
        this.usuarioInsercao = usuarioInsercao;
    }

    public Date getDtManutencao() {
        return dtManutencao;
    }

    public void setDtManutencao(Date dtManutencao) {
        this.dtManutencao = dtManutencao;
    }

    public String getUsuarioManutencao() {
        return usuarioManutencao;
    }

    public void setUsuarioManutencao(String usuarioManutencao) {
        this.usuarioManutencao = usuarioManutencao;
    }

    public BigInteger getCdGrpProdutoInst() {
        return cdGrpProdutoInst;
    }

    public void setCdGrpProdutoInst(BigInteger cdGrpProdutoInst) {
        this.cdGrpProdutoInst = cdGrpProdutoInst;
    }

    public Long getCdOperacaoOriginal() {
        return cdOperacaoOriginal;
    }

    public void setCdOperacaoOriginal(Long cdOperacaoOriginal) {
        this.cdOperacaoOriginal = cdOperacaoOriginal;
    }
    
}
