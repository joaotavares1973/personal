/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class Tta275OpeNotifiEmailPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "CD_COD_OPE")
    private BigInteger cdCodOpe;
    @Basic(optional = false)
    @Column(name = "CD_COD_EMAIL")
    private BigInteger cdCodEmail;

    public Tta275OpeNotifiEmailPK() {
    }

    public Tta275OpeNotifiEmailPK(BigInteger cdCodOpe, BigInteger cdCodEmail) {
        this.cdCodOpe = cdCodOpe;
        this.cdCodEmail = cdCodEmail;
    }

    public BigInteger getCdCodOpe() {
        return cdCodOpe;
    }

    public void setCdCodOpe(BigInteger cdCodOpe) {
        this.cdCodOpe = cdCodOpe;
    }

    public BigInteger getCdCodEmail() {
        return cdCodEmail;
    }

    public void setCdCodEmail(BigInteger cdCodEmail) {
        this.cdCodEmail = cdCodEmail;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdCodOpe != null ? cdCodOpe.hashCode() : 0);
        hash += (cdCodEmail != null ? cdCodEmail.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta275OpeNotifiEmailPK)) {
            return false;
        }
        Tta275OpeNotifiEmailPK other = (Tta275OpeNotifiEmailPK) object;
        if ((this.cdCodOpe == null && other.cdCodOpe != null) || (this.cdCodOpe != null && !this.cdCodOpe.equals(other.cdCodOpe))) {
            return false;
        }
        if ((this.cdCodEmail == null && other.cdCodEmail != null) || (this.cdCodEmail != null && !this.cdCodEmail.equals(other.cdCodEmail))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta275OpeNotifiEmailPK[ cdCodOpe=" + cdCodOpe + ", cdCodEmail=" + cdCodEmail + " ]";
    }
    
}
