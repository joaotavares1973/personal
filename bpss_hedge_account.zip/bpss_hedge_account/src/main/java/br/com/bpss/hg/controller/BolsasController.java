package br.com.bpss.hg.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;

import br.com.bpss.hg.domain.Tta020JBolsa;
import br.com.bpss.hg.repository.BolsasRepository;
import br.com.bpss.hg.service.GenericService;
import br.com.bpss.hg.service.PermissoesService;

@Controller
public class BolsasController {

	@Autowired
	private BolsasRepository bolsasRepository;

	@Autowired
	private GenericService genericService;

	@Autowired
	GenericService utils;

	@Autowired
	PermissoesService permissoesService;

	final static Logger logger = Logger.getLogger(BolsasController.class);

	@RequestMapping(value = "/bolsas.bpss", method = RequestMethod.GET)
	public String gestorOperacoes(Model model, HttpSession session, SessionStatus status) {

		boolean permissao = permissoesService.permicaoAutorizada((String) session.getAttribute("usuario"), "200");

		if (!permissao)
			return "jsp/usuarioSemPermissao";

		List<Tta020JBolsa> bolsas = bolsasRepository.listarBolsas();

		model.addAttribute("bolsas", bolsas);


		return "jsp/listarBolsas";

	}

}