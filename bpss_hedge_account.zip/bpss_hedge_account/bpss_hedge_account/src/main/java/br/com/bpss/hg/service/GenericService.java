package br.com.bpss.hg.service;

public interface GenericService {
	
	public Object getParametrosView();
	
}
