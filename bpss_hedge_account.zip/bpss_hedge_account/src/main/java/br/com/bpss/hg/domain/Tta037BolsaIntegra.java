/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA037_BOLSA_INTEGRA")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta037BolsaIntegra.findAll", query = "SELECT t FROM Tta037BolsaIntegra t"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdIntegraBolsa", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.tta037BolsaIntegraPK.cdIntegraBolsa = :cdIntegraBolsa"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdParametroSupProd", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.tta037BolsaIntegraPK.cdParametroSupProd = :cdParametroSupProd"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdParametroInfProd", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.tta037BolsaIntegraPK.cdParametroInfProd = :cdParametroInfProd"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByNmGrpProduto", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.nmGrpProduto = :nmGrpProduto"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdNaBolsa", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.cdNaBolsa = :cdNaBolsa"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdGrpProduto", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdOrigemCma", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.cdOrigemCma = :cdOrigemCma"),
    @NamedQuery(name = "Tta037BolsaIntegra.findByCdNaBolsaBc", query = "SELECT t FROM Tta037BolsaIntegra t WHERE t.cdNaBolsaBc = :cdNaBolsaBc")})
public class Tta037BolsaIntegra implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tta037BolsaIntegraPK tta037BolsaIntegraPK;
    @Column(name = "NM_GRP_PRODUTO")
    private String nmGrpProduto;
    @Column(name = "CD_NA_BOLSA")
    private String cdNaBolsa;
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Column(name = "CD_ORIGEM_CMA")
    private BigInteger cdOrigemCma;
    @Column(name = "CD_NA_BOLSA_BC")
    private String cdNaBolsaBc;

    public Tta037BolsaIntegra() {
    }

    public Tta037BolsaIntegra(Tta037BolsaIntegraPK tta037BolsaIntegraPK) {
        this.tta037BolsaIntegraPK = tta037BolsaIntegraPK;
    }

    public Tta037BolsaIntegra(String cdIntegraBolsa, short cdParametroSupProd, int cdParametroInfProd) {
        this.tta037BolsaIntegraPK = new Tta037BolsaIntegraPK(cdIntegraBolsa, cdParametroSupProd, cdParametroInfProd);
    }

    public Tta037BolsaIntegraPK getTta037BolsaIntegraPK() {
        return tta037BolsaIntegraPK;
    }

    public void setTta037BolsaIntegraPK(Tta037BolsaIntegraPK tta037BolsaIntegraPK) {
        this.tta037BolsaIntegraPK = tta037BolsaIntegraPK;
    }

    public String getNmGrpProduto() {
        return nmGrpProduto;
    }

    public void setNmGrpProduto(String nmGrpProduto) {
        this.nmGrpProduto = nmGrpProduto;
    }

    public String getCdNaBolsa() {
        return cdNaBolsa;
    }

    public void setCdNaBolsa(String cdNaBolsa) {
        this.cdNaBolsa = cdNaBolsa;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public BigInteger getCdOrigemCma() {
        return cdOrigemCma;
    }

    public void setCdOrigemCma(BigInteger cdOrigemCma) {
        this.cdOrigemCma = cdOrigemCma;
    }

    public String getCdNaBolsaBc() {
        return cdNaBolsaBc;
    }

    public void setCdNaBolsaBc(String cdNaBolsaBc) {
        this.cdNaBolsaBc = cdNaBolsaBc;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tta037BolsaIntegraPK != null ? tta037BolsaIntegraPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta037BolsaIntegra)) {
            return false;
        }
        Tta037BolsaIntegra other = (Tta037BolsaIntegra) object;
        if ((this.tta037BolsaIntegraPK == null && other.tta037BolsaIntegraPK != null) || (this.tta037BolsaIntegraPK != null && !this.tta037BolsaIntegraPK.equals(other.tta037BolsaIntegraPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta037BolsaIntegra[ tta037BolsaIntegraPK=" + tta037BolsaIntegraPK + " ]";
    }
    
}
