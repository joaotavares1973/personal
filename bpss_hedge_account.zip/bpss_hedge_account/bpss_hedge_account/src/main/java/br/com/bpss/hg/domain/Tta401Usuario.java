/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA401_USUARIO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta401Usuario.findAll", query = "SELECT t FROM Tta401Usuario t"),
    @NamedQuery(name = "Tta401Usuario.findByCdUsuario", query = "SELECT t FROM Tta401Usuario t WHERE t.cdUsuario = :cdUsuario"),
    @NamedQuery(name = "Tta401Usuario.findByEmail", query = "SELECT t FROM Tta401Usuario t WHERE t.email = :email"),
    @NamedQuery(name = "Tta401Usuario.findByDiretorio", query = "SELECT t FROM Tta401Usuario t WHERE t.diretorio = :diretorio"),
    @NamedQuery(name = "Tta401Usuario.findByCdUsuarioManutencao", query = "SELECT t FROM Tta401Usuario t WHERE t.cdUsuarioManutencao = :cdUsuarioManutencao"),
    @NamedQuery(name = "Tta401Usuario.findByDhSysManutencao", query = "SELECT t FROM Tta401Usuario t WHERE t.dhSysManutencao = :dhSysManutencao"),
    @NamedQuery(name = "Tta401Usuario.findByFlStatus", query = "SELECT t FROM Tta401Usuario t WHERE t.flStatus = :flStatus"),
    @NamedQuery(name = "Tta401Usuario.findByFlAdmSistema", query = "SELECT t FROM Tta401Usuario t WHERE t.flAdmSistema = :flAdmSistema"),
    @NamedQuery(name = "Tta401Usuario.findByNmSenhaUsuario", query = "SELECT t FROM Tta401Usuario t WHERE t.nmSenhaUsuario = :nmSenhaUsuario"),
    @NamedQuery(name = "Tta401Usuario.findByNmSenhaPadrao", query = "SELECT t FROM Tta401Usuario t WHERE t.nmSenhaPadrao = :nmSenhaPadrao")})
public class Tta401Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_USUARIO")
    private String cdUsuario;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "DIRETORIO")
    private String diretorio;
    @Basic(optional = false)
    @Column(name = "CD_USUARIO_MANUTENCAO")
    private String cdUsuarioManutencao;
    @Column(name = "DH_SYS_MANUTENCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysManutencao;
    @Basic(optional = false)
    @Column(name = "FL_STATUS")
    private Character flStatus;
    @Column(name = "FL_ADM_SISTEMA")
    private BigInteger flAdmSistema;
    @Column(name = "NM_SENHA_USUARIO")
    private String nmSenhaUsuario;
    @Column(name = "NM_SENHA_PADRAO")
    private String nmSenhaPadrao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tta401Usuario")
    private Collection<Tta402UsuarioCentroLucro> tta402UsuarioCentroLucroCollection;
    @JoinColumn(name = "FK_ID_GRUPO", referencedColumnName = "ID_GRUPO")
    @ManyToOne
    private Tta410Grupo fkIdGrupo;

    public Tta401Usuario() {
    }

    public Tta401Usuario(String cdUsuario) {
        this.cdUsuario = cdUsuario;
    }

    public Tta401Usuario(String cdUsuario, String cdUsuarioManutencao, Character flStatus) {
        this.cdUsuario = cdUsuario;
        this.cdUsuarioManutencao = cdUsuarioManutencao;
        this.flStatus = flStatus;
    }

    public String getCdUsuario() {
        return cdUsuario;
    }

    public void setCdUsuario(String cdUsuario) {
        this.cdUsuario = cdUsuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDiretorio() {
        return diretorio;
    }

    public void setDiretorio(String diretorio) {
        this.diretorio = diretorio;
    }

    public String getCdUsuarioManutencao() {
        return cdUsuarioManutencao;
    }

    public void setCdUsuarioManutencao(String cdUsuarioManutencao) {
        this.cdUsuarioManutencao = cdUsuarioManutencao;
    }

    public Date getDhSysManutencao() {
        return dhSysManutencao;
    }

    public void setDhSysManutencao(Date dhSysManutencao) {
        this.dhSysManutencao = dhSysManutencao;
    }

    public Character getFlStatus() {
        return flStatus;
    }

    public void setFlStatus(Character flStatus) {
        this.flStatus = flStatus;
    }

    public BigInteger getFlAdmSistema() {
        return flAdmSistema;
    }

    public void setFlAdmSistema(BigInteger flAdmSistema) {
        this.flAdmSistema = flAdmSistema;
    }

    public String getNmSenhaUsuario() {
        return nmSenhaUsuario;
    }

    public void setNmSenhaUsuario(String nmSenhaUsuario) {
        this.nmSenhaUsuario = nmSenhaUsuario;
    }

    public String getNmSenhaPadrao() {
        return nmSenhaPadrao;
    }

    public void setNmSenhaPadrao(String nmSenhaPadrao) {
        this.nmSenhaPadrao = nmSenhaPadrao;
    }

    @XmlTransient
    public Collection<Tta402UsuarioCentroLucro> getTta402UsuarioCentroLucroCollection() {
        return tta402UsuarioCentroLucroCollection;
    }

    public void setTta402UsuarioCentroLucroCollection(Collection<Tta402UsuarioCentroLucro> tta402UsuarioCentroLucroCollection) {
        this.tta402UsuarioCentroLucroCollection = tta402UsuarioCentroLucroCollection;
    }

    public Tta410Grupo getFkIdGrupo() {
        return fkIdGrupo;
    }

    public void setFkIdGrupo(Tta410Grupo fkIdGrupo) {
        this.fkIdGrupo = fkIdGrupo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdUsuario != null ? cdUsuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta401Usuario)) {
            return false;
        }
        Tta401Usuario other = (Tta401Usuario) object;
        if ((this.cdUsuario == null && other.cdUsuario != null) || (this.cdUsuario != null && !this.cdUsuario.equals(other.cdUsuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta401Usuario[ cdUsuario=" + cdUsuario + " ]";
    }
    
}
