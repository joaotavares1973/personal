/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA110_J_GRP_PRODUTO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta110JGrpProduto.findAll", query = "SELECT t FROM Tta110JGrpProduto t"),
    @NamedQuery(name = "Tta110JGrpProduto.findByCdGrpProduto", query = "SELECT t FROM Tta110JGrpProduto t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tta110JGrpProduto.findByNmGrpProduto", query = "SELECT t FROM Tta110JGrpProduto t WHERE t.nmGrpProduto = :nmGrpProduto")})
public class Tta110JGrpProduto implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "NM_GRP_PRODUTO")
    private String nmGrpProduto;

    public Tta110JGrpProduto() {
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getNmGrpProduto() {
        return nmGrpProduto;
    }

    public void setNmGrpProduto(String nmGrpProduto) {
        this.nmGrpProduto = nmGrpProduto;
    }
    
}
