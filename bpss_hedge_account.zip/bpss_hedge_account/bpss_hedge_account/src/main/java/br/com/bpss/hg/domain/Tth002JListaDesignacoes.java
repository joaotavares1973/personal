/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH002_J_LISTA_DESIGNACOES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth002JListaDesignacoes.findAll", query = "SELECT t FROM Tth002JListaDesignacoes t"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByDesignacao", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.designacao = :designacao"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByTipoInstrumento", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.tipoInstrumento = :tipoInstrumento"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByDsTipoInstrumento", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.dsTipoInstrumento = :dsTipoInstrumento"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByCdGrpProduto", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByNmGrpProduto", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.nmGrpProduto = :nmGrpProduto"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByDtAlocacao", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.dtAlocacao = :dtAlocacao"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByAnoSafra", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.anoSafra = :anoSafra"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByMesAno", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.mesAno = :mesAno"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByStatus", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.status = :status"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByObjetoHedge", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.objetoHedge = :objetoHedge"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByQtdeFisica", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.qtdeFisica = :qtdeFisica"),
    @NamedQuery(name = "Tth002JListaDesignacoes.findByQtdeHedge", query = "SELECT t FROM Tth002JListaDesignacoes t WHERE t.qtdeHedge = :qtdeHedge")})
public class Tth002JListaDesignacoes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "DESIGNACAO")
    private long designacao;
    @Column(name = "TIPO_INSTRUMENTO")
    private BigInteger tipoInstrumento;
    @Column(name = "DS_TIPO_INSTRUMENTO")
    private String dsTipoInstrumento;
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "NM_GRP_PRODUTO")
    private String nmGrpProduto;
    @Column(name = "DT_ALOCACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtAlocacao;
    @Column(name = "ANO_SAFRA")
    private String anoSafra;
    @Column(name = "MES_ANO")
    private String mesAno;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "OBJETO_HEDGE")
    private String objetoHedge;
    @Column(name = "QTDE_FISICA")
    private BigInteger qtdeFisica;
    @Column(name = "QTDE_HEDGE")
    private BigInteger qtdeHedge;

    public Tth002JListaDesignacoes() {
    }

    public long getDesignacao() {
        return designacao;
    }

    public void setDesignacao(long designacao) {
        this.designacao = designacao;
    }

    public BigInteger getTipoInstrumento() {
        return tipoInstrumento;
    }

    public void setTipoInstrumento(BigInteger tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }

    public String getDsTipoInstrumento() {
        return dsTipoInstrumento;
    }

    public void setDsTipoInstrumento(String dsTipoInstrumento) {
        this.dsTipoInstrumento = dsTipoInstrumento;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getNmGrpProduto() {
        return nmGrpProduto;
    }

    public void setNmGrpProduto(String nmGrpProduto) {
        this.nmGrpProduto = nmGrpProduto;
    }

    public Date getDtAlocacao() {
        return dtAlocacao;
    }

    public void setDtAlocacao(Date dtAlocacao) {
        this.dtAlocacao = dtAlocacao;
    }

    public String getAnoSafra() {
        return anoSafra;
    }

    public void setAnoSafra(String anoSafra) {
        this.anoSafra = anoSafra;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getObjetoHedge() {
        return objetoHedge;
    }

    public void setObjetoHedge(String objetoHedge) {
        this.objetoHedge = objetoHedge;
    }

    public BigInteger getQtdeFisica() {
        return qtdeFisica;
    }

    public void setQtdeFisica(BigInteger qtdeFisica) {
        this.qtdeFisica = qtdeFisica;
    }

    public BigInteger getQtdeHedge() {
        return qtdeHedge;
    }

    public void setQtdeHedge(BigInteger qtdeHedge) {
        this.qtdeHedge = qtdeHedge;
    }
    
}
