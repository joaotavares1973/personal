/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA035_BOLSA_PRODUTO_PERIODO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta035BolsaProdutoPeriodo.findAll", query = "SELECT t FROM Tta035BolsaProdutoPeriodo t"),
    @NamedQuery(name = "Tta035BolsaProdutoPeriodo.findByCdGrpProduto", query = "SELECT t FROM Tta035BolsaProdutoPeriodo t WHERE t.tta035BolsaProdutoPeriodoPK.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tta035BolsaProdutoPeriodo.findByDsMesEmbarque", query = "SELECT t FROM Tta035BolsaProdutoPeriodo t WHERE t.tta035BolsaProdutoPeriodoPK.dsMesEmbarque = :dsMesEmbarque"),
    @NamedQuery(name = "Tta035BolsaProdutoPeriodo.findByDsMesBolsa", query = "SELECT t FROM Tta035BolsaProdutoPeriodo t WHERE t.dsMesBolsa = :dsMesBolsa"),
    @NamedQuery(name = "Tta035BolsaProdutoPeriodo.findByFlProximoAno", query = "SELECT t FROM Tta035BolsaProdutoPeriodo t WHERE t.flProximoAno = :flProximoAno"),
    @NamedQuery(name = "Tta035BolsaProdutoPeriodo.findByCdBolsa", query = "SELECT t FROM Tta035BolsaProdutoPeriodo t WHERE t.cdBolsa = :cdBolsa")})
public class Tta035BolsaProdutoPeriodo implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tta035BolsaProdutoPeriodoPK tta035BolsaProdutoPeriodoPK;
    @Basic(optional = false)
    @Column(name = "DS_MES_BOLSA")
    private String dsMesBolsa;
    @Basic(optional = false)
    @Column(name = "FL_PROXIMO_ANO")
    private Character flProximoAno;
    @Column(name = "CD_BOLSA")
    private Character cdBolsa;
    @JoinColumn(name = "CD_GRP_PRODUTO", referencedColumnName = "CD_GRP_PRODUTO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta110GrpProduto tta110GrpProduto;

    public Tta035BolsaProdutoPeriodo() {
    }

    public Tta035BolsaProdutoPeriodo(Tta035BolsaProdutoPeriodoPK tta035BolsaProdutoPeriodoPK) {
        this.tta035BolsaProdutoPeriodoPK = tta035BolsaProdutoPeriodoPK;
    }

    public Tta035BolsaProdutoPeriodo(Tta035BolsaProdutoPeriodoPK tta035BolsaProdutoPeriodoPK, String dsMesBolsa, Character flProximoAno) {
        this.tta035BolsaProdutoPeriodoPK = tta035BolsaProdutoPeriodoPK;
        this.dsMesBolsa = dsMesBolsa;
        this.flProximoAno = flProximoAno;
    }

    public Tta035BolsaProdutoPeriodo(BigInteger cdGrpProduto, String dsMesEmbarque) {
        this.tta035BolsaProdutoPeriodoPK = new Tta035BolsaProdutoPeriodoPK(cdGrpProduto, dsMesEmbarque);
    }

    public Tta035BolsaProdutoPeriodoPK getTta035BolsaProdutoPeriodoPK() {
        return tta035BolsaProdutoPeriodoPK;
    }

    public void setTta035BolsaProdutoPeriodoPK(Tta035BolsaProdutoPeriodoPK tta035BolsaProdutoPeriodoPK) {
        this.tta035BolsaProdutoPeriodoPK = tta035BolsaProdutoPeriodoPK;
    }

    public String getDsMesBolsa() {
        return dsMesBolsa;
    }

    public void setDsMesBolsa(String dsMesBolsa) {
        this.dsMesBolsa = dsMesBolsa;
    }

    public Character getFlProximoAno() {
        return flProximoAno;
    }

    public void setFlProximoAno(Character flProximoAno) {
        this.flProximoAno = flProximoAno;
    }

    public Character getCdBolsa() {
        return cdBolsa;
    }

    public void setCdBolsa(Character cdBolsa) {
        this.cdBolsa = cdBolsa;
    }

    public Tta110GrpProduto getTta110GrpProduto() {
        return tta110GrpProduto;
    }

    public void setTta110GrpProduto(Tta110GrpProduto tta110GrpProduto) {
        this.tta110GrpProduto = tta110GrpProduto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tta035BolsaProdutoPeriodoPK != null ? tta035BolsaProdutoPeriodoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta035BolsaProdutoPeriodo)) {
            return false;
        }
        Tta035BolsaProdutoPeriodo other = (Tta035BolsaProdutoPeriodo) object;
        if ((this.tta035BolsaProdutoPeriodoPK == null && other.tta035BolsaProdutoPeriodoPK != null) || (this.tta035BolsaProdutoPeriodoPK != null && !this.tta035BolsaProdutoPeriodoPK.equals(other.tta035BolsaProdutoPeriodoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta035BolsaProdutoPeriodo[ tta035BolsaProdutoPeriodoPK=" + tta035BolsaProdutoPeriodoPK + " ]";
    }
    
}
