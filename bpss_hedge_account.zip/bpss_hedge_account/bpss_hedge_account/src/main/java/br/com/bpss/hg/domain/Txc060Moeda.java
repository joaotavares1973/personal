/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TXC060_MOEDA")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Txc060Moeda.findAll", query = "SELECT t FROM Txc060Moeda t"),
    @NamedQuery(name = "Txc060Moeda.findByCdMoeda", query = "SELECT t FROM Txc060Moeda t WHERE t.cdMoeda = :cdMoeda"),
    @NamedQuery(name = "Txc060Moeda.findByDsMoeda", query = "SELECT t FROM Txc060Moeda t WHERE t.dsMoeda = :dsMoeda"),
    @NamedQuery(name = "Txc060Moeda.findBySgMoeda", query = "SELECT t FROM Txc060Moeda t WHERE t.sgMoeda = :sgMoeda"),
    @NamedQuery(name = "Txc060Moeda.findByCdUsuarioManutencao", query = "SELECT t FROM Txc060Moeda t WHERE t.cdUsuarioManutencao = :cdUsuarioManutencao"),
    @NamedQuery(name = "Txc060Moeda.findByDhSysManutencao", query = "SELECT t FROM Txc060Moeda t WHERE t.dhSysManutencao = :dhSysManutencao")})
public class Txc060Moeda implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_MOEDA")
    private Short cdMoeda;
    @Basic(optional = false)
    @Column(name = "DS_MOEDA")
    private String dsMoeda;
    @Column(name = "SG_MOEDA")
    private String sgMoeda;
    @Basic(optional = false)
    @Column(name = "CD_USUARIO_MANUTENCAO")
    private String cdUsuarioManutencao;
    @Basic(optional = false)
    @Column(name = "DH_SYS_MANUTENCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysManutencao;

    public Txc060Moeda() {
    }

    public Txc060Moeda(Short cdMoeda) {
        this.cdMoeda = cdMoeda;
    }

    public Txc060Moeda(Short cdMoeda, String dsMoeda, String cdUsuarioManutencao, Date dhSysManutencao) {
        this.cdMoeda = cdMoeda;
        this.dsMoeda = dsMoeda;
        this.cdUsuarioManutencao = cdUsuarioManutencao;
        this.dhSysManutencao = dhSysManutencao;
    }

    public Short getCdMoeda() {
        return cdMoeda;
    }

    public void setCdMoeda(Short cdMoeda) {
        this.cdMoeda = cdMoeda;
    }

    public String getDsMoeda() {
        return dsMoeda;
    }

    public void setDsMoeda(String dsMoeda) {
        this.dsMoeda = dsMoeda;
    }

    public String getSgMoeda() {
        return sgMoeda;
    }

    public void setSgMoeda(String sgMoeda) {
        this.sgMoeda = sgMoeda;
    }

    public String getCdUsuarioManutencao() {
        return cdUsuarioManutencao;
    }

    public void setCdUsuarioManutencao(String cdUsuarioManutencao) {
        this.cdUsuarioManutencao = cdUsuarioManutencao;
    }

    public Date getDhSysManutencao() {
        return dhSysManutencao;
    }

    public void setDhSysManutencao(Date dhSysManutencao) {
        this.dhSysManutencao = dhSysManutencao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdMoeda != null ? cdMoeda.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Txc060Moeda)) {
            return false;
        }
        Txc060Moeda other = (Txc060Moeda) object;
        if ((this.cdMoeda == null && other.cdMoeda != null) || (this.cdMoeda != null && !this.cdMoeda.equals(other.cdMoeda))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Txc060Moeda[ cdMoeda=" + cdMoeda + " ]";
    }
    
}
