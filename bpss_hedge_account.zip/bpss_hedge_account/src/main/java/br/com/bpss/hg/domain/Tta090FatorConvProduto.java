/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA090_FATOR_CONV_PRODUTO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta090FatorConvProduto.findAll", query = "SELECT t FROM Tta090FatorConvProduto t"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByCdProduto", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.cdProduto = :cdProduto"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByVlFator", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.vlFator = :vlFator"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByQtFator", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.qtFator = :qtFator"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByVlFatorBush", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.vlFatorBush = :vlFatorBush"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByQtFatorCtr", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.qtFatorCtr = :qtFatorCtr"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByFatorMultiplCtr", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.fatorMultiplCtr = :fatorMultiplCtr"),
    @NamedQuery(name = "Tta090FatorConvProduto.findByVlFatorBushExp", query = "SELECT t FROM Tta090FatorConvProduto t WHERE t.vlFatorBushExp = :vlFatorBushExp")})
public class Tta090FatorConvProduto implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_PRODUTO")
    private Integer cdProduto;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "VL_FATOR")
    private BigDecimal vlFator;
    @Basic(optional = false)
    @Column(name = "QT_FATOR")
    private BigDecimal qtFator;
    @Basic(optional = false)
    @Column(name = "VL_FATOR_BUSH")
    private BigDecimal vlFatorBush;
    @Basic(optional = false)
    @Column(name = "QT_FATOR_CTR")
    private BigDecimal qtFatorCtr;
    @Column(name = "FATOR_MULTIPL_CTR")
    private BigDecimal fatorMultiplCtr;
    @Column(name = "VL_FATOR_BUSH_EXP")
    private BigDecimal vlFatorBushExp;

    public Tta090FatorConvProduto() {
    }

    public Tta090FatorConvProduto(Integer cdProduto) {
        this.cdProduto = cdProduto;
    }

    public Tta090FatorConvProduto(Integer cdProduto, BigDecimal vlFator, BigDecimal qtFator, BigDecimal vlFatorBush, BigDecimal qtFatorCtr) {
        this.cdProduto = cdProduto;
        this.vlFator = vlFator;
        this.qtFator = qtFator;
        this.vlFatorBush = vlFatorBush;
        this.qtFatorCtr = qtFatorCtr;
    }

    public Integer getCdProduto() {
        return cdProduto;
    }

    public void setCdProduto(Integer cdProduto) {
        this.cdProduto = cdProduto;
    }

    public BigDecimal getVlFator() {
        return vlFator;
    }

    public void setVlFator(BigDecimal vlFator) {
        this.vlFator = vlFator;
    }

    public BigDecimal getQtFator() {
        return qtFator;
    }

    public void setQtFator(BigDecimal qtFator) {
        this.qtFator = qtFator;
    }

    public BigDecimal getVlFatorBush() {
        return vlFatorBush;
    }

    public void setVlFatorBush(BigDecimal vlFatorBush) {
        this.vlFatorBush = vlFatorBush;
    }

    public BigDecimal getQtFatorCtr() {
        return qtFatorCtr;
    }

    public void setQtFatorCtr(BigDecimal qtFatorCtr) {
        this.qtFatorCtr = qtFatorCtr;
    }

    public BigDecimal getFatorMultiplCtr() {
        return fatorMultiplCtr;
    }

    public void setFatorMultiplCtr(BigDecimal fatorMultiplCtr) {
        this.fatorMultiplCtr = fatorMultiplCtr;
    }

    public BigDecimal getVlFatorBushExp() {
        return vlFatorBushExp;
    }

    public void setVlFatorBushExp(BigDecimal vlFatorBushExp) {
        this.vlFatorBushExp = vlFatorBushExp;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdProduto != null ? cdProduto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta090FatorConvProduto)) {
            return false;
        }
        Tta090FatorConvProduto other = (Tta090FatorConvProduto) object;
        if ((this.cdProduto == null && other.cdProduto != null) || (this.cdProduto != null && !this.cdProduto.equals(other.cdProduto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta090FatorConvProduto[ cdProduto=" + cdProduto + " ]";
    }

}
