/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA302_J_VALIDA_PERM_SIMPLES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta302JValidaPermSimples.findAll", query = "SELECT t FROM Tta302JValidaPermSimples t"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByIdPermissao", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.idPermissao = :idPermissao"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByNmPermissao", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.nmPermissao = :nmPermissao"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByDsPermissao", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.dsPermissao = :dsPermissao"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByFlVerifEmp", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.flVerifEmp = :flVerifEmp"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByFlVerifNeg", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.flVerifNeg = :flVerifNeg"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByFlVerifProd", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.flVerifProd = :flVerifProd"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByFkIdGrupo", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.fkIdGrupo = :fkIdGrupo"),
    @NamedQuery(name = "Tta302JValidaPermSimples.findByCdUsuario", query = "SELECT t FROM Tta302JValidaPermSimples t WHERE t.cdUsuario = :cdUsuario")})
public class Tta302JValidaPermSimples implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_PERMISSAO")
    private BigInteger idPermissao;
    @Basic(optional = false)
    @Column(name = "NM_PERMISSAO")
    private String nmPermissao;
    @Column(name = "DS_PERMISSAO")
    private String dsPermissao;
    @Column(name = "FL_VERIF_EMP")
    private String flVerifEmp;
    @Column(name = "FL_VERIF_NEG")
    private String flVerifNeg;
    @Column(name = "FL_VERIF_PROD")
    private String flVerifProd;
    @Basic(optional = false)
    @Column(name = "FK_ID_GRUPO")
    private BigInteger fkIdGrupo;
    @Basic(optional = false)
    @Column(name = "CD_USUARIO")
    private String cdUsuario;

    public Tta302JValidaPermSimples() {
    }

    public BigInteger getIdPermissao() {
        return idPermissao;
    }

    public void setIdPermissao(BigInteger idPermissao) {
        this.idPermissao = idPermissao;
    }

    public String getNmPermissao() {
        return nmPermissao;
    }

    public void setNmPermissao(String nmPermissao) {
        this.nmPermissao = nmPermissao;
    }

    public String getDsPermissao() {
        return dsPermissao;
    }

    public void setDsPermissao(String dsPermissao) {
        this.dsPermissao = dsPermissao;
    }

    public String getFlVerifEmp() {
        return flVerifEmp;
    }

    public void setFlVerifEmp(String flVerifEmp) {
        this.flVerifEmp = flVerifEmp;
    }

    public String getFlVerifNeg() {
        return flVerifNeg;
    }

    public void setFlVerifNeg(String flVerifNeg) {
        this.flVerifNeg = flVerifNeg;
    }

    public String getFlVerifProd() {
        return flVerifProd;
    }

    public void setFlVerifProd(String flVerifProd) {
        this.flVerifProd = flVerifProd;
    }

    public BigInteger getFkIdGrupo() {
        return fkIdGrupo;
    }

    public void setFkIdGrupo(BigInteger fkIdGrupo) {
        this.fkIdGrupo = fkIdGrupo;
    }

    public String getCdUsuario() {
        return cdUsuario;
    }

    public void setCdUsuario(String cdUsuario) {
        this.cdUsuario = cdUsuario;
    }
    
}
