/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA411_PERMISSAO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta411Permissao.findAll", query = "SELECT t FROM Tta411Permissao t"),
    @NamedQuery(name = "Tta411Permissao.findByIdPermissao", query = "SELECT t FROM Tta411Permissao t WHERE t.idPermissao = :idPermissao"),
    @NamedQuery(name = "Tta411Permissao.findByNmPermissao", query = "SELECT t FROM Tta411Permissao t WHERE t.nmPermissao = :nmPermissao"),
    @NamedQuery(name = "Tta411Permissao.findByDsPermissao", query = "SELECT t FROM Tta411Permissao t WHERE t.dsPermissao = :dsPermissao"),
    @NamedQuery(name = "Tta411Permissao.findByCdNivel1", query = "SELECT t FROM Tta411Permissao t WHERE t.cdNivel1 = :cdNivel1"),
    @NamedQuery(name = "Tta411Permissao.findByCdNivel2", query = "SELECT t FROM Tta411Permissao t WHERE t.cdNivel2 = :cdNivel2"),
    @NamedQuery(name = "Tta411Permissao.findByNmIcone", query = "SELECT t FROM Tta411Permissao t WHERE t.nmIcone = :nmIcone")})
public class Tta411Permissao implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "ID_PERMISSAO")
    private BigDecimal idPermissao;
    @Basic(optional = false)
    @Column(name = "NM_PERMISSAO")
    private String nmPermissao;
    @Column(name = "DS_PERMISSAO")
    private String dsPermissao;
    @Column(name = "CD_NIVEL_1")
    private Short cdNivel1;
    @Column(name = "CD_NIVEL_2")
    private Short cdNivel2;
    @Column(name = "NM_ICONE")
    private String nmIcone;
    @JoinTable(name = "TTA412_GRUPO_PERMISSAO", joinColumns = {
        @JoinColumn(name = "FK_ID_PERMISSAO", referencedColumnName = "ID_PERMISSAO")}, inverseJoinColumns = {
        @JoinColumn(name = "FK_ID_GRUPO", referencedColumnName = "ID_GRUPO")})
    @ManyToMany
    private Collection<Tta410Grupo> tta410GrupoCollection;
    @JoinColumn(name = "CD_FUNCAO", referencedColumnName = "CD_FUNCAO")
    @ManyToOne
    private Tta309Funcao cdFuncao;
    @JoinColumn(name = "CD_MODULO", referencedColumnName = "CD_MODULO")
    @ManyToOne
    private Tta308ModulosBpss cdModulo;

    public Tta411Permissao() {
    }

    public Tta411Permissao(BigDecimal idPermissao) {
        this.idPermissao = idPermissao;
    }

    public Tta411Permissao(BigDecimal idPermissao, String nmPermissao) {
        this.idPermissao = idPermissao;
        this.nmPermissao = nmPermissao;
    }

    public BigDecimal getIdPermissao() {
        return idPermissao;
    }

    public void setIdPermissao(BigDecimal idPermissao) {
        this.idPermissao = idPermissao;
    }

    public String getNmPermissao() {
        return nmPermissao;
    }

    public void setNmPermissao(String nmPermissao) {
        this.nmPermissao = nmPermissao;
    }

    public String getDsPermissao() {
        return dsPermissao;
    }

    public void setDsPermissao(String dsPermissao) {
        this.dsPermissao = dsPermissao;
    }

    public Short getCdNivel1() {
        return cdNivel1;
    }

    public void setCdNivel1(Short cdNivel1) {
        this.cdNivel1 = cdNivel1;
    }

    public Short getCdNivel2() {
        return cdNivel2;
    }

    public void setCdNivel2(Short cdNivel2) {
        this.cdNivel2 = cdNivel2;
    }

    public String getNmIcone() {
        return nmIcone;
    }

    public void setNmIcone(String nmIcone) {
        this.nmIcone = nmIcone;
    }

    @XmlTransient
    public Collection<Tta410Grupo> getTta410GrupoCollection() {
        return tta410GrupoCollection;
    }

    public void setTta410GrupoCollection(Collection<Tta410Grupo> tta410GrupoCollection) {
        this.tta410GrupoCollection = tta410GrupoCollection;
    }

    public Tta309Funcao getCdFuncao() {
        return cdFuncao;
    }

    public void setCdFuncao(Tta309Funcao cdFuncao) {
        this.cdFuncao = cdFuncao;
    }

    public Tta308ModulosBpss getCdModulo() {
        return cdModulo;
    }

    public void setCdModulo(Tta308ModulosBpss cdModulo) {
        this.cdModulo = cdModulo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPermissao != null ? idPermissao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta411Permissao)) {
            return false;
        }
        Tta411Permissao other = (Tta411Permissao) object;
        if ((this.idPermissao == null && other.idPermissao != null) || (this.idPermissao != null && !this.idPermissao.equals(other.idPermissao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta411Permissao[ idPermissao=" + idPermissao + " ]";
    }
    
}
