/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA091_FATOR_CONV_PRODUTO_BOLS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findAll", query = "SELECT t FROM Tta091FatorConvProdutoBols t"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByCdProduto", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.tta091FatorConvProdutoBolsPK.cdProduto = :cdProduto"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByCdBolsa", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.tta091FatorConvProdutoBolsPK.cdBolsa = :cdBolsa"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByVlFator", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.vlFator = :vlFator"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByQtFator", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.qtFator = :qtFator"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByVlFatorBush", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.vlFatorBush = :vlFatorBush"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByQtFatorCtr", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.qtFatorCtr = :qtFatorCtr"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByFatorMultiplCtr", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.fatorMultiplCtr = :fatorMultiplCtr"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByVlFatorBushExp", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.vlFatorBushExp = :vlFatorBushExp"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByCdUsuarioManutencao", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.cdUsuarioManutencao = :cdUsuarioManutencao"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByDhSysManutencao", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.dhSysManutencao = :dhSysManutencao"),
    @NamedQuery(name = "Tta091FatorConvProdutoBols.findByCdNaBolsa", query = "SELECT t FROM Tta091FatorConvProdutoBols t WHERE t.cdNaBolsa = :cdNaBolsa")})
public class Tta091FatorConvProdutoBols implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tta091FatorConvProdutoBolsPK tta091FatorConvProdutoBolsPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "VL_FATOR")
    private BigDecimal vlFator;
    @Basic(optional = false)
    @Column(name = "QT_FATOR")
    private BigDecimal qtFator;
    @Basic(optional = false)
    @Column(name = "VL_FATOR_BUSH")
    private BigDecimal vlFatorBush;
    @Basic(optional = false)
    @Column(name = "QT_FATOR_CTR")
    private BigDecimal qtFatorCtr;
    @Column(name = "FATOR_MULTIPL_CTR")
    private BigDecimal fatorMultiplCtr;
    @Column(name = "VL_FATOR_BUSH_EXP")
    private BigDecimal vlFatorBushExp;
    @Basic(optional = false)
    @Column(name = "CD_USUARIO_MANUTENCAO")
    private String cdUsuarioManutencao;
    @Basic(optional = false)
    @Column(name = "DH_SYS_MANUTENCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysManutencao;
    @Column(name = "CD_NA_BOLSA")
    private String cdNaBolsa;
    @JoinColumn(name = "CD_PRODUTO", referencedColumnName = "CD_GRP_PRODUTO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta110GrpProduto tta110GrpProduto;
    @JoinColumn(name = "CD_BOLSA", referencedColumnName = "CD_BOLSA", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta020Bolsa tta020Bolsa;

    public Tta091FatorConvProdutoBols() {
    }

    public Tta091FatorConvProdutoBols(Tta091FatorConvProdutoBolsPK tta091FatorConvProdutoBolsPK) {
        this.tta091FatorConvProdutoBolsPK = tta091FatorConvProdutoBolsPK;
    }

    public Tta091FatorConvProdutoBols(Tta091FatorConvProdutoBolsPK tta091FatorConvProdutoBolsPK, BigDecimal vlFator, BigDecimal qtFator, BigDecimal vlFatorBush, BigDecimal qtFatorCtr, String cdUsuarioManutencao, Date dhSysManutencao) {
        this.tta091FatorConvProdutoBolsPK = tta091FatorConvProdutoBolsPK;
        this.vlFator = vlFator;
        this.qtFator = qtFator;
        this.vlFatorBush = vlFatorBush;
        this.qtFatorCtr = qtFatorCtr;
        this.cdUsuarioManutencao = cdUsuarioManutencao;
        this.dhSysManutencao = dhSysManutencao;
    }

    public Tta091FatorConvProdutoBols(int cdProduto, BigInteger cdBolsa) {
        this.tta091FatorConvProdutoBolsPK = new Tta091FatorConvProdutoBolsPK(cdProduto, cdBolsa);
    }

    public Tta091FatorConvProdutoBolsPK getTta091FatorConvProdutoBolsPK() {
        return tta091FatorConvProdutoBolsPK;
    }

    public void setTta091FatorConvProdutoBolsPK(Tta091FatorConvProdutoBolsPK tta091FatorConvProdutoBolsPK) {
        this.tta091FatorConvProdutoBolsPK = tta091FatorConvProdutoBolsPK;
    }

    public BigDecimal getVlFator() {
        return vlFator;
    }

    public void setVlFator(BigDecimal vlFator) {
        this.vlFator = vlFator;
    }

    public BigDecimal getQtFator() {
        return qtFator;
    }

    public void setQtFator(BigDecimal qtFator) {
        this.qtFator = qtFator;
    }

    public BigDecimal getVlFatorBush() {
        return vlFatorBush;
    }

    public void setVlFatorBush(BigDecimal vlFatorBush) {
        this.vlFatorBush = vlFatorBush;
    }

    public BigDecimal getQtFatorCtr() {
        return qtFatorCtr;
    }

    public void setQtFatorCtr(BigDecimal qtFatorCtr) {
        this.qtFatorCtr = qtFatorCtr;
    }

    public BigDecimal getFatorMultiplCtr() {
        return fatorMultiplCtr;
    }

    public void setFatorMultiplCtr(BigDecimal fatorMultiplCtr) {
        this.fatorMultiplCtr = fatorMultiplCtr;
    }

    public BigDecimal getVlFatorBushExp() {
        return vlFatorBushExp;
    }

    public void setVlFatorBushExp(BigDecimal vlFatorBushExp) {
        this.vlFatorBushExp = vlFatorBushExp;
    }

    public String getCdUsuarioManutencao() {
        return cdUsuarioManutencao;
    }

    public void setCdUsuarioManutencao(String cdUsuarioManutencao) {
        this.cdUsuarioManutencao = cdUsuarioManutencao;
    }

    public Date getDhSysManutencao() {
        return dhSysManutencao;
    }

    public void setDhSysManutencao(Date dhSysManutencao) {
        this.dhSysManutencao = dhSysManutencao;
    }

    public String getCdNaBolsa() {
        return cdNaBolsa;
    }

    public void setCdNaBolsa(String cdNaBolsa) {
        this.cdNaBolsa = cdNaBolsa;
    }

    public Tta110GrpProduto getTta110GrpProduto() {
        return tta110GrpProduto;
    }

    public void setTta110GrpProduto(Tta110GrpProduto tta110GrpProduto) {
        this.tta110GrpProduto = tta110GrpProduto;
    }

    public Tta020Bolsa getTta020Bolsa() {
        return tta020Bolsa;
    }

    public void setTta020Bolsa(Tta020Bolsa tta020Bolsa) {
        this.tta020Bolsa = tta020Bolsa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tta091FatorConvProdutoBolsPK != null ? tta091FatorConvProdutoBolsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta091FatorConvProdutoBols)) {
            return false;
        }
        Tta091FatorConvProdutoBols other = (Tta091FatorConvProdutoBols) object;
        if ((this.tta091FatorConvProdutoBolsPK == null && other.tta091FatorConvProdutoBolsPK != null) || (this.tta091FatorConvProdutoBolsPK != null && !this.tta091FatorConvProdutoBolsPK.equals(other.tta091FatorConvProdutoBolsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta091FatorConvProdutoBols[ tta091FatorConvProdutoBolsPK=" + tta091FatorConvProdutoBolsPK + " ]";
    }
    
}
