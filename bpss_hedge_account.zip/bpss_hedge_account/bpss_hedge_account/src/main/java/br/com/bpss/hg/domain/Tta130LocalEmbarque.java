/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA130_LOCAL_EMBARQUE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta130LocalEmbarque.findAll", query = "SELECT t FROM Tta130LocalEmbarque t"),
    @NamedQuery(name = "Tta130LocalEmbarque.findByCdLocalEmbarque", query = "SELECT t FROM Tta130LocalEmbarque t WHERE t.cdLocalEmbarque = :cdLocalEmbarque"),
    @NamedQuery(name = "Tta130LocalEmbarque.findByNmLocalEmbarque", query = "SELECT t FROM Tta130LocalEmbarque t WHERE t.nmLocalEmbarque = :nmLocalEmbarque"),
    @NamedQuery(name = "Tta130LocalEmbarque.findByCdLocalEmbarqueSq", query = "SELECT t FROM Tta130LocalEmbarque t WHERE t.cdLocalEmbarqueSq = :cdLocalEmbarqueSq"),
    @NamedQuery(name = "Tta130LocalEmbarque.findByFlLocal", query = "SELECT t FROM Tta130LocalEmbarque t WHERE t.flLocal = :flLocal"),
    @NamedQuery(name = "Tta130LocalEmbarque.findByCdCidade", query = "SELECT t FROM Tta130LocalEmbarque t WHERE t.cdCidade = :cdCidade")})
public class Tta130LocalEmbarque implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_LOCAL_EMBARQUE")
    private Integer cdLocalEmbarque;
    @Basic(optional = false)
    @Column(name = "NM_LOCAL_EMBARQUE")
    private String nmLocalEmbarque;
    @Column(name = "CD_LOCAL_EMBARQUE_SQ")
    private BigInteger cdLocalEmbarqueSq;
    @Column(name = "FL_LOCAL")
    private Character flLocal;
    @Column(name = "CD_CIDADE")
    private Integer cdCidade;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tta130LocalEmbarque")
    private Collection<Ttv304ValoresMercado> ttv304ValoresMercadoCollection;

    public Tta130LocalEmbarque() {
    }

    public Tta130LocalEmbarque(Integer cdLocalEmbarque) {
        this.cdLocalEmbarque = cdLocalEmbarque;
    }

    public Tta130LocalEmbarque(Integer cdLocalEmbarque, String nmLocalEmbarque) {
        this.cdLocalEmbarque = cdLocalEmbarque;
        this.nmLocalEmbarque = nmLocalEmbarque;
    }

    public Integer getCdLocalEmbarque() {
        return cdLocalEmbarque;
    }

    public void setCdLocalEmbarque(Integer cdLocalEmbarque) {
        this.cdLocalEmbarque = cdLocalEmbarque;
    }

    public String getNmLocalEmbarque() {
        return nmLocalEmbarque;
    }

    public void setNmLocalEmbarque(String nmLocalEmbarque) {
        this.nmLocalEmbarque = nmLocalEmbarque;
    }

    public BigInteger getCdLocalEmbarqueSq() {
        return cdLocalEmbarqueSq;
    }

    public void setCdLocalEmbarqueSq(BigInteger cdLocalEmbarqueSq) {
        this.cdLocalEmbarqueSq = cdLocalEmbarqueSq;
    }

    public Character getFlLocal() {
        return flLocal;
    }

    public void setFlLocal(Character flLocal) {
        this.flLocal = flLocal;
    }

    public Integer getCdCidade() {
        return cdCidade;
    }

    public void setCdCidade(Integer cdCidade) {
        this.cdCidade = cdCidade;
    }

    @XmlTransient
    public Collection<Ttv304ValoresMercado> getTtv304ValoresMercadoCollection() {
        return ttv304ValoresMercadoCollection;
    }

    public void setTtv304ValoresMercadoCollection(Collection<Ttv304ValoresMercado> ttv304ValoresMercadoCollection) {
        this.ttv304ValoresMercadoCollection = ttv304ValoresMercadoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdLocalEmbarque != null ? cdLocalEmbarque.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta130LocalEmbarque)) {
            return false;
        }
        Tta130LocalEmbarque other = (Tta130LocalEmbarque) object;
        if ((this.cdLocalEmbarque == null && other.cdLocalEmbarque != null) || (this.cdLocalEmbarque != null && !this.cdLocalEmbarque.equals(other.cdLocalEmbarque))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta130LocalEmbarque[ cdLocalEmbarque=" + cdLocalEmbarque + " ]";
    }
    
}
