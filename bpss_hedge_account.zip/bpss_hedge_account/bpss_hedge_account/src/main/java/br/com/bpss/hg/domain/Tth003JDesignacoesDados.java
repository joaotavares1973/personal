/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH003_J_DESIGNACOES_DADOS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth003JDesignacoesDados.findAll", query = "SELECT t FROM Tth003JDesignacoesDados t"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByDesignacao", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.designacao = :designacao"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByTipoInstrumento", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.tipoInstrumento = :tipoInstrumento"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByDsTipoInstrumento", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.dsTipoInstrumento = :dsTipoInstrumento"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByCdGrpProduto", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByNmGrpProduto", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.nmGrpProduto = :nmGrpProduto"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByDtAlocacao", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.dtAlocacao = :dtAlocacao"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByAnoSafra", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.anoSafra = :anoSafra"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByMesAnoAlocacao", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.mesAnoAlocacao = :mesAnoAlocacao"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByStatus", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.status = :status"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByObjetoHedge", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.objetoHedge = :objetoHedge"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByTipo", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.tipo = :tipo"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByContrato", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.contrato = :contrato"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByCdOperacao", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.cdOperacao = :cdOperacao"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByMesAno", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.mesAno = :mesAno"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByQtde", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.qtde = :qtde"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByVlrUnit", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.vlrUnit = :vlrUnit"),
    @NamedQuery(name = "Tth003JDesignacoesDados.findByVlrUsd", query = "SELECT t FROM Tth003JDesignacoesDados t WHERE t.vlrUsd = :vlrUsd")})
public class Tth003JDesignacoesDados implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "DESIGNACAO")
    private long designacao;
    @Column(name = "TIPO_INSTRUMENTO")
    private BigInteger tipoInstrumento;
    @Column(name = "DS_TIPO_INSTRUMENTO")
    private String dsTipoInstrumento;
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Column(name = "NM_GRP_PRODUTO")
    private String nmGrpProduto;
    @Column(name = "DT_ALOCACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtAlocacao;
    @Column(name = "ANO_SAFRA")
    private String anoSafra;
    @Column(name = "MES_ANO_ALOCACAO")
    private String mesAnoAlocacao;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "OBJETO_HEDGE")
    private String objetoHedge;
    @Column(name = "TIPO")
    private String tipo;
    @Basic(optional = false)
    @Column(name = "CONTRATO")
    private long contrato;
    @Basic(optional = false)
    @Column(name = "CD_OPERACAO")
    private long cdOperacao;
    @Column(name = "MES_ANO")
    private String mesAno;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "QTDE")
    private BigDecimal qtde;
    @Column(name = "VLR_UNIT")
    private BigDecimal vlrUnit;
    @Column(name = "VLR_USD")
    private BigInteger vlrUsd;

    public Tth003JDesignacoesDados() {
    }

    public long getDesignacao() {
        return designacao;
    }

    public void setDesignacao(long designacao) {
        this.designacao = designacao;
    }

    public BigInteger getTipoInstrumento() {
        return tipoInstrumento;
    }

    public void setTipoInstrumento(BigInteger tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }

    public String getDsTipoInstrumento() {
        return dsTipoInstrumento;
    }

    public void setDsTipoInstrumento(String dsTipoInstrumento) {
        this.dsTipoInstrumento = dsTipoInstrumento;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getNmGrpProduto() {
        return nmGrpProduto;
    }

    public void setNmGrpProduto(String nmGrpProduto) {
        this.nmGrpProduto = nmGrpProduto;
    }

    public Date getDtAlocacao() {
        return dtAlocacao;
    }

    public void setDtAlocacao(Date dtAlocacao) {
        this.dtAlocacao = dtAlocacao;
    }

    public String getAnoSafra() {
        return anoSafra;
    }

    public void setAnoSafra(String anoSafra) {
        this.anoSafra = anoSafra;
    }

    public String getMesAnoAlocacao() {
        return mesAnoAlocacao;
    }

    public void setMesAnoAlocacao(String mesAnoAlocacao) {
        this.mesAnoAlocacao = mesAnoAlocacao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getObjetoHedge() {
        return objetoHedge;
    }

    public void setObjetoHedge(String objetoHedge) {
        this.objetoHedge = objetoHedge;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public long getContrato() {
        return contrato;
    }

    public void setContrato(long contrato) {
        this.contrato = contrato;
    }

    public long getCdOperacao() {
        return cdOperacao;
    }

    public void setCdOperacao(long cdOperacao) {
        this.cdOperacao = cdOperacao;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public BigDecimal getQtde() {
        return qtde;
    }

    public void setQtde(BigDecimal qtde) {
        this.qtde = qtde;
    }

    public BigDecimal getVlrUnit() {
        return vlrUnit;
    }

    public void setVlrUnit(BigDecimal vlrUnit) {
        this.vlrUnit = vlrUnit;
    }

    public BigInteger getVlrUsd() {
        return vlrUsd;
    }

    public void setVlrUsd(BigInteger vlrUsd) {
        this.vlrUsd = vlrUsd;
    }
    
}
