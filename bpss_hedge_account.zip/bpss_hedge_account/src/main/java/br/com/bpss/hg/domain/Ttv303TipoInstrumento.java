/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV303_TIPO_INSTRUMENTO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv303TipoInstrumento.findAll", query = "SELECT t FROM Ttv303TipoInstrumento t"),
    @NamedQuery(name = "Ttv303TipoInstrumento.findByCdTipoInstrumento", query = "SELECT t FROM Ttv303TipoInstrumento t WHERE t.cdTipoInstrumento = :cdTipoInstrumento"),
    @NamedQuery(name = "Ttv303TipoInstrumento.findByDsTipoInstrumento", query = "SELECT t FROM Ttv303TipoInstrumento t WHERE t.dsTipoInstrumento = :dsTipoInstrumento")})
public class Ttv303TipoInstrumento implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "CD_TIPO_INSTRUMENTO")
    private BigDecimal cdTipoInstrumento;
    @Column(name = "DS_TIPO_INSTRUMENTO")
    private String dsTipoInstrumento;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ttv303TipoInstrumento")
    private Collection<Ttv304ValoresMercado> ttv304ValoresMercadoCollection;
    @OneToMany(mappedBy = "cdTipoInstrumento")
    private Collection<Tth002DesignacaoHdr> tth002DesignacaoHdrCollection;
    @OneToMany(mappedBy = "cdTipoInstrumento")
    private Collection<Tta104FixacaoTipo> tta104FixacaoTipoCollection;

    public Ttv303TipoInstrumento() {
    }

    public Ttv303TipoInstrumento(BigDecimal cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    public BigDecimal getCdTipoInstrumento() {
        return cdTipoInstrumento;
    }

    public void setCdTipoInstrumento(BigDecimal cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    public String getDsTipoInstrumento() {
        return dsTipoInstrumento;
    }

    public void setDsTipoInstrumento(String dsTipoInstrumento) {
        this.dsTipoInstrumento = dsTipoInstrumento;
    }

    @XmlTransient
    public Collection<Ttv304ValoresMercado> getTtv304ValoresMercadoCollection() {
        return ttv304ValoresMercadoCollection;
    }

    public void setTtv304ValoresMercadoCollection(Collection<Ttv304ValoresMercado> ttv304ValoresMercadoCollection) {
        this.ttv304ValoresMercadoCollection = ttv304ValoresMercadoCollection;
    }

    @XmlTransient
    public Collection<Tth002DesignacaoHdr> getTth002DesignacaoHdrCollection() {
        return tth002DesignacaoHdrCollection;
    }

    public void setTth002DesignacaoHdrCollection(Collection<Tth002DesignacaoHdr> tth002DesignacaoHdrCollection) {
        this.tth002DesignacaoHdrCollection = tth002DesignacaoHdrCollection;
    }

    @XmlTransient
    public Collection<Tta104FixacaoTipo> getTta104FixacaoTipoCollection() {
        return tta104FixacaoTipoCollection;
    }

    public void setTta104FixacaoTipoCollection(Collection<Tta104FixacaoTipo> tta104FixacaoTipoCollection) {
        this.tta104FixacaoTipoCollection = tta104FixacaoTipoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdTipoInstrumento != null ? cdTipoInstrumento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ttv303TipoInstrumento)) {
            return false;
        }
        Ttv303TipoInstrumento other = (Ttv303TipoInstrumento) object;
        if ((this.cdTipoInstrumento == null && other.cdTipoInstrumento != null) || (this.cdTipoInstrumento != null && !this.cdTipoInstrumento.equals(other.cdTipoInstrumento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Ttv303TipoInstrumento[ cdTipoInstrumento=" + cdTipoInstrumento + " ]";
    }
    
}
