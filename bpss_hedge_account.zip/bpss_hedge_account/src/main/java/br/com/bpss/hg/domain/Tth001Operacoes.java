/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH001_OPERACOES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth001Operacoes.findAll", query = "SELECT t FROM Tth001Operacoes t"),
    @NamedQuery(name = "Tth001Operacoes.findByCdOperacao", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdOperacao = :cdOperacao"),
    @NamedQuery(name = "Tth001Operacoes.findByCdContratoHdr", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdContratoHdr = :cdContratoHdr"),
    @NamedQuery(name = "Tth001Operacoes.findByCdFixacaoTipo", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdFixacaoTipo = :cdFixacaoTipo"),
    @NamedQuery(name = "Tth001Operacoes.findByCdFixacaoContrato", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdFixacaoContrato = :cdFixacaoContrato"),
    @NamedQuery(name = "Tth001Operacoes.findByCdGrpProduto", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tth001Operacoes.findByCdSeqRolagem", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdSeqRolagem = :cdSeqRolagem"),
    @NamedQuery(name = "Tth001Operacoes.findByFlTipoMercado", query = "SELECT t FROM Tth001Operacoes t WHERE t.flTipoMercado = :flTipoMercado"),
    @NamedQuery(name = "Tth001Operacoes.findByDtNegociacao", query = "SELECT t FROM Tth001Operacoes t WHERE t.dtNegociacao = :dtNegociacao"),
    @NamedQuery(name = "Tth001Operacoes.findByAnoSafra", query = "SELECT t FROM Tth001Operacoes t WHERE t.anoSafra = :anoSafra"),
    @NamedQuery(name = "Tth001Operacoes.findByAnoMes", query = "SELECT t FROM Tth001Operacoes t WHERE t.anoMes = :anoMes"),
    @NamedQuery(name = "Tth001Operacoes.findByCdTipoOperacao", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdTipoOperacao = :cdTipoOperacao"),
    @NamedQuery(name = "Tth001Operacoes.findByNuContratoInterno", query = "SELECT t FROM Tth001Operacoes t WHERE t.nuContratoInterno = :nuContratoInterno"),
    @NamedQuery(name = "Tth001Operacoes.findByQtde", query = "SELECT t FROM Tth001Operacoes t WHERE t.qtde = :qtde"),
    @NamedQuery(name = "Tth001Operacoes.findByVlrFixado", query = "SELECT t FROM Tth001Operacoes t WHERE t.vlrFixado = :vlrFixado"),
    @NamedQuery(name = "Tth001Operacoes.findByDtFixacao", query = "SELECT t FROM Tth001Operacoes t WHERE t.dtFixacao = :dtFixacao"),
    @NamedQuery(name = "Tth001Operacoes.findByFlDesignacao", query = "SELECT t FROM Tth001Operacoes t WHERE t.flDesignacao = :flDesignacao"),
    @NamedQuery(name = "Tth001Operacoes.findByFlTipo", query = "SELECT t FROM Tth001Operacoes t WHERE t.flTipo = :flTipo"),
    @NamedQuery(name = "Tth001Operacoes.findByDhSysInsercao", query = "SELECT t FROM Tth001Operacoes t WHERE t.dhSysInsercao = :dhSysInsercao"),
    @NamedQuery(name = "Tth001Operacoes.findByCdUsuarioInsercao", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdUsuarioInsercao = :cdUsuarioInsercao"),
    @NamedQuery(name = "Tth001Operacoes.findByDhSysManutencao", query = "SELECT t FROM Tth001Operacoes t WHERE t.dhSysManutencao = :dhSysManutencao"),
    @NamedQuery(name = "Tth001Operacoes.findByCdUsuarioManutencao", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdUsuarioManutencao = :cdUsuarioManutencao"),
    @NamedQuery(name = "Tth001Operacoes.findByCdGrpProdutoInst", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdGrpProdutoInst = :cdGrpProdutoInst"),
    @NamedQuery(name = "Tth001Operacoes.findByVlrSpread", query = "SELECT t FROM Tth001Operacoes t WHERE t.vlrSpread = :vlrSpread"),
    @NamedQuery(name = "Tth001Operacoes.findByCdOperacaoOriginal", query = "SELECT t FROM Tth001Operacoes t WHERE t.cdOperacaoOriginal = :cdOperacaoOriginal"),
    @NamedQuery(name = "Tth001Operacoes.findByDtExpiracao", query = "SELECT t FROM Tth001Operacoes t WHERE t.dtExpiracao = :dtExpiracao")})
public class Tth001Operacoes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_OPERACAO")
    private Long cdOperacao;
    @Basic(optional = false)
    @Column(name = "CD_CONTRATO_HDR")
    private long cdContratoHdr;
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_TIPO")
    private BigInteger cdFixacaoTipo;
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_CONTRATO")
    private BigInteger cdFixacaoContrato;
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigInteger cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "CD_SEQ_ROLAGEM")
    private BigInteger cdSeqRolagem;
    @Column(name = "FL_TIPO_MERCADO")
    private String flTipoMercado;
    @Column(name = "DT_NEGOCIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtNegociacao;
    @Column(name = "ANO_SAFRA")
    private String anoSafra;
    @Column(name = "ANO_MES")
    private String anoMes;
    @Column(name = "CD_TIPO_OPERACAO")
    private BigInteger cdTipoOperacao;
    @Column(name = "NU_CONTRATO_INTERNO")
    private String nuContratoInterno;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "QTDE")
    private BigDecimal qtde;
    @Column(name = "VLR_FIXADO")
    private BigDecimal vlrFixado;
    @Column(name = "DT_FIXACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtFixacao;
    @Column(name = "FL_DESIGNACAO")
    private Character flDesignacao;
    @Column(name = "FL_TIPO")
    private Character flTipo;
    @Column(name = "DH_SYS_INSERCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysInsercao;
    @Column(name = "CD_USUARIO_INSERCAO")
    private String cdUsuarioInsercao;
    @Column(name = "DH_SYS_MANUTENCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysManutencao;
    @Column(name = "CD_USUARIO_MANUTENCAO")
    private String cdUsuarioManutencao;
    @Column(name = "CD_GRP_PRODUTO_INST")
    private BigInteger cdGrpProdutoInst;
    @Column(name = "VLR_SPREAD")
    private BigDecimal vlrSpread;
    @Column(name = "CD_OPERACAO_ORIGINAL")
    private Long cdOperacaoOriginal;
    @Column(name = "DT_EXPIRACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtExpiracao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tth001Operacoes")
    private Collection<Tth003DesignacaoDtl> tth003DesignacaoDtlCollection;

    public Tth001Operacoes() {
    }

    public Tth001Operacoes(Long cdOperacao) {
        this.cdOperacao = cdOperacao;
    }

    public Tth001Operacoes(Long cdOperacao, long cdContratoHdr, BigInteger cdFixacaoTipo, BigInteger cdFixacaoContrato, BigInteger cdGrpProduto, BigInteger cdSeqRolagem) {
        this.cdOperacao = cdOperacao;
        this.cdContratoHdr = cdContratoHdr;
        this.cdFixacaoTipo = cdFixacaoTipo;
        this.cdFixacaoContrato = cdFixacaoContrato;
        this.cdGrpProduto = cdGrpProduto;
        this.cdSeqRolagem = cdSeqRolagem;
    }

    public Long getCdOperacao() {
        return cdOperacao;
    }

    public void setCdOperacao(Long cdOperacao) {
        this.cdOperacao = cdOperacao;
    }

    public long getCdContratoHdr() {
        return cdContratoHdr;
    }

    public void setCdContratoHdr(long cdContratoHdr) {
        this.cdContratoHdr = cdContratoHdr;
    }

    public BigInteger getCdFixacaoTipo() {
        return cdFixacaoTipo;
    }

    public void setCdFixacaoTipo(BigInteger cdFixacaoTipo) {
        this.cdFixacaoTipo = cdFixacaoTipo;
    }

    public BigInteger getCdFixacaoContrato() {
        return cdFixacaoContrato;
    }

    public void setCdFixacaoContrato(BigInteger cdFixacaoContrato) {
        this.cdFixacaoContrato = cdFixacaoContrato;
    }

    public BigInteger getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigInteger cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public BigInteger getCdSeqRolagem() {
        return cdSeqRolagem;
    }

    public void setCdSeqRolagem(BigInteger cdSeqRolagem) {
        this.cdSeqRolagem = cdSeqRolagem;
    }

    public String getFlTipoMercado() {
        return flTipoMercado;
    }

    public void setFlTipoMercado(String flTipoMercado) {
        this.flTipoMercado = flTipoMercado;
    }

    public Date getDtNegociacao() {
        return dtNegociacao;
    }

    public void setDtNegociacao(Date dtNegociacao) {
        this.dtNegociacao = dtNegociacao;
    }

    public String getAnoSafra() {
        return anoSafra;
    }

    public void setAnoSafra(String anoSafra) {
        this.anoSafra = anoSafra;
    }

    public String getAnoMes() {
        return anoMes;
    }

    public void setAnoMes(String anoMes) {
        this.anoMes = anoMes;
    }

    public BigInteger getCdTipoOperacao() {
        return cdTipoOperacao;
    }

    public void setCdTipoOperacao(BigInteger cdTipoOperacao) {
        this.cdTipoOperacao = cdTipoOperacao;
    }

    public String getNuContratoInterno() {
        return nuContratoInterno;
    }

    public void setNuContratoInterno(String nuContratoInterno) {
        this.nuContratoInterno = nuContratoInterno;
    }

    public BigDecimal getQtde() {
        return qtde;
    }

    public void setQtde(BigDecimal qtde) {
        this.qtde = qtde;
    }

    public BigDecimal getVlrFixado() {
        return vlrFixado;
    }

    public void setVlrFixado(BigDecimal vlrFixado) {
        this.vlrFixado = vlrFixado;
    }

    public Date getDtFixacao() {
        return dtFixacao;
    }

    public void setDtFixacao(Date dtFixacao) {
        this.dtFixacao = dtFixacao;
    }

    public Character getFlDesignacao() {
        return flDesignacao;
    }

    public void setFlDesignacao(Character flDesignacao) {
        this.flDesignacao = flDesignacao;
    }

    public Character getFlTipo() {
        return flTipo;
    }

    public void setFlTipo(Character flTipo) {
        this.flTipo = flTipo;
    }

    public Date getDhSysInsercao() {
        return dhSysInsercao;
    }

    public void setDhSysInsercao(Date dhSysInsercao) {
        this.dhSysInsercao = dhSysInsercao;
    }

    public String getCdUsuarioInsercao() {
        return cdUsuarioInsercao;
    }

    public void setCdUsuarioInsercao(String cdUsuarioInsercao) {
        this.cdUsuarioInsercao = cdUsuarioInsercao;
    }

    public Date getDhSysManutencao() {
        return dhSysManutencao;
    }

    public void setDhSysManutencao(Date dhSysManutencao) {
        this.dhSysManutencao = dhSysManutencao;
    }

    public String getCdUsuarioManutencao() {
        return cdUsuarioManutencao;
    }

    public void setCdUsuarioManutencao(String cdUsuarioManutencao) {
        this.cdUsuarioManutencao = cdUsuarioManutencao;
    }

    public BigInteger getCdGrpProdutoInst() {
        return cdGrpProdutoInst;
    }

    public void setCdGrpProdutoInst(BigInteger cdGrpProdutoInst) {
        this.cdGrpProdutoInst = cdGrpProdutoInst;
    }

    public BigDecimal getVlrSpread() {
        return vlrSpread;
    }

    public void setVlrSpread(BigDecimal vlrSpread) {
        this.vlrSpread = vlrSpread;
    }

    public Long getCdOperacaoOriginal() {
        return cdOperacaoOriginal;
    }

    public void setCdOperacaoOriginal(Long cdOperacaoOriginal) {
        this.cdOperacaoOriginal = cdOperacaoOriginal;
    }

    public Date getDtExpiracao() {
        return dtExpiracao;
    }

    public void setDtExpiracao(Date dtExpiracao) {
        this.dtExpiracao = dtExpiracao;
    }

    @XmlTransient
    public Collection<Tth003DesignacaoDtl> getTth003DesignacaoDtlCollection() {
        return tth003DesignacaoDtlCollection;
    }

    public void setTth003DesignacaoDtlCollection(Collection<Tth003DesignacaoDtl> tth003DesignacaoDtlCollection) {
        this.tth003DesignacaoDtlCollection = tth003DesignacaoDtlCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdOperacao != null ? cdOperacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tth001Operacoes)) {
            return false;
        }
        Tth001Operacoes other = (Tth001Operacoes) object;
        if ((this.cdOperacao == null && other.cdOperacao != null) || (this.cdOperacao != null && !this.cdOperacao.equals(other.cdOperacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tth001Operacoes[ cdOperacao=" + cdOperacao + " ]";
    }
    
}
