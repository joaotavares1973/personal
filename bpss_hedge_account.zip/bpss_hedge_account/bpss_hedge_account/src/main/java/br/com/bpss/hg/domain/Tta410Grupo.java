/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA410_GRUPO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta410Grupo.findAll", query = "SELECT t FROM Tta410Grupo t"),
    @NamedQuery(name = "Tta410Grupo.findByIdGrupo", query = "SELECT t FROM Tta410Grupo t WHERE t.idGrupo = :idGrupo"),
    @NamedQuery(name = "Tta410Grupo.findByNmGrupo", query = "SELECT t FROM Tta410Grupo t WHERE t.nmGrupo = :nmGrupo"),
    @NamedQuery(name = "Tta410Grupo.findByDsGrupo", query = "SELECT t FROM Tta410Grupo t WHERE t.dsGrupo = :dsGrupo"),
    @NamedQuery(name = "Tta410Grupo.findByFlInterno", query = "SELECT t FROM Tta410Grupo t WHERE t.flInterno = :flInterno")})
public class Tta410Grupo implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "ID_GRUPO")
    private BigDecimal idGrupo;
    @Basic(optional = false)
    @Column(name = "NM_GRUPO")
    private String nmGrupo;
    @Column(name = "DS_GRUPO")
    private String dsGrupo;
    @Basic(optional = false)
    @Column(name = "FL_INTERNO")
    private Character flInterno;
    @ManyToMany(mappedBy = "tta410GrupoCollection")
    private Collection<Tta411Permissao> tta411PermissaoCollection;
    @OneToMany(mappedBy = "fkIdGrupo")
    private Collection<Tta401Usuario> tta401UsuarioCollection;

    public Tta410Grupo() {
    }

    public Tta410Grupo(BigDecimal idGrupo) {
        this.idGrupo = idGrupo;
    }

    public Tta410Grupo(BigDecimal idGrupo, String nmGrupo, Character flInterno) {
        this.idGrupo = idGrupo;
        this.nmGrupo = nmGrupo;
        this.flInterno = flInterno;
    }

    public BigDecimal getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(BigDecimal idGrupo) {
        this.idGrupo = idGrupo;
    }

    public String getNmGrupo() {
        return nmGrupo;
    }

    public void setNmGrupo(String nmGrupo) {
        this.nmGrupo = nmGrupo;
    }

    public String getDsGrupo() {
        return dsGrupo;
    }

    public void setDsGrupo(String dsGrupo) {
        this.dsGrupo = dsGrupo;
    }

    public Character getFlInterno() {
        return flInterno;
    }

    public void setFlInterno(Character flInterno) {
        this.flInterno = flInterno;
    }

    @XmlTransient
    public Collection<Tta411Permissao> getTta411PermissaoCollection() {
        return tta411PermissaoCollection;
    }

    public void setTta411PermissaoCollection(Collection<Tta411Permissao> tta411PermissaoCollection) {
        this.tta411PermissaoCollection = tta411PermissaoCollection;
    }

    @XmlTransient
    public Collection<Tta401Usuario> getTta401UsuarioCollection() {
        return tta401UsuarioCollection;
    }

    public void setTta401UsuarioCollection(Collection<Tta401Usuario> tta401UsuarioCollection) {
        this.tta401UsuarioCollection = tta401UsuarioCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idGrupo != null ? idGrupo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta410Grupo)) {
            return false;
        }
        Tta410Grupo other = (Tta410Grupo) object;
        if ((this.idGrupo == null && other.idGrupo != null) || (this.idGrupo != null && !this.idGrupo.equals(other.idGrupo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta410Grupo[ idGrupo=" + idGrupo + " ]";
    }
    
}
