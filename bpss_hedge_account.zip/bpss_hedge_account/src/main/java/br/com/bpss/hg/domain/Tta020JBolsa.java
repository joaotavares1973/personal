/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA020_J_BOLSA")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta020JBolsa.findAll", query = "SELECT t FROM Tta020JBolsa t"),
    @NamedQuery(name = "Tta020JBolsa.findByCdBolsa", query = "SELECT t FROM Tta020JBolsa t WHERE t.cdBolsa = :cdBolsa"),
    @NamedQuery(name = "Tta020JBolsa.findByNmBolsa", query = "SELECT t FROM Tta020JBolsa t WHERE t.nmBolsa = :nmBolsa")})
public class Tta020JBolsa implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_BOLSA")
    private BigInteger cdBolsa;
    @Basic(optional = false)
    @Column(name = "NM_BOLSA")
    private String nmBolsa;

    public Tta020JBolsa() {
    }

    public BigInteger getCdBolsa() {
        return cdBolsa;
    }

    public void setCdBolsa(BigInteger cdBolsa) {
        this.cdBolsa = cdBolsa;
    }

    public String getNmBolsa() {
        return nmBolsa;
    }

    public void setNmBolsa(String nmBolsa) {
        this.nmBolsa = nmBolsa;
    }
    
}
