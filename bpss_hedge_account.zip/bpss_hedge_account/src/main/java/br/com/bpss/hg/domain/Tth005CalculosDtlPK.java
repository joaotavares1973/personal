/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class Tth005CalculosDtlPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "CD_CALCULO")
    private long cdCalculo;
    @Basic(optional = false)
    @Column(name = "CD_DESIGNACAO")
    private long cdDesignacao;
    @Basic(optional = false)
    @Column(name = "CD_OPERACAO")
    private long cdOperacao;

    public Tth005CalculosDtlPK() {
    }

    public Tth005CalculosDtlPK(long cdCalculo, long cdDesignacao, long cdOperacao) {
        this.cdCalculo = cdCalculo;
        this.cdDesignacao = cdDesignacao;
        this.cdOperacao = cdOperacao;
    }

    public long getCdCalculo() {
        return cdCalculo;
    }

    public void setCdCalculo(long cdCalculo) {
        this.cdCalculo = cdCalculo;
    }

    public long getCdDesignacao() {
        return cdDesignacao;
    }

    public void setCdDesignacao(long cdDesignacao) {
        this.cdDesignacao = cdDesignacao;
    }

    public long getCdOperacao() {
        return cdOperacao;
    }

    public void setCdOperacao(long cdOperacao) {
        this.cdOperacao = cdOperacao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cdCalculo;
        hash += (int) cdDesignacao;
        hash += (int) cdOperacao;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tth005CalculosDtlPK)) {
            return false;
        }
        Tth005CalculosDtlPK other = (Tth005CalculosDtlPK) object;
        if (this.cdCalculo != other.cdCalculo) {
            return false;
        }
        if (this.cdDesignacao != other.cdDesignacao) {
            return false;
        }
        if (this.cdOperacao != other.cdOperacao) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tth005CalculosDtlPK[ cdCalculo=" + cdCalculo + ", cdDesignacao=" + cdDesignacao + ", cdOperacao=" + cdOperacao + " ]";
    }
    
}
