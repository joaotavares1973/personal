package br.com.bpss.hg.service;

public interface PermissoesService {
	
	public boolean permicaoAutorizada(String usuario, String idPermissao);
	
}