/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA110_GRP_PRODUTO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta110GrpProduto.findAll", query = "SELECT t FROM Tta110GrpProduto t"),
    @NamedQuery(name = "Tta110GrpProduto.findByCdGrpProduto", query = "SELECT t FROM Tta110GrpProduto t WHERE t.cdGrpProduto = :cdGrpProduto"),
    @NamedQuery(name = "Tta110GrpProduto.findByNmGrpProduto", query = "SELECT t FROM Tta110GrpProduto t WHERE t.nmGrpProduto = :nmGrpProduto"),
    @NamedQuery(name = "Tta110GrpProduto.findByCdNegocio", query = "SELECT t FROM Tta110GrpProduto t WHERE t.cdNegocio = :cdNegocio"),
    @NamedQuery(name = "Tta110GrpProduto.findByUnMedida", query = "SELECT t FROM Tta110GrpProduto t WHERE t.unMedida = :unMedida"),
    @NamedQuery(name = "Tta110GrpProduto.findByPercentVlComissao", query = "SELECT t FROM Tta110GrpProduto t WHERE t.percentVlComissao = :percentVlComissao"),
    @NamedQuery(name = "Tta110GrpProduto.findByNumOrder", query = "SELECT t FROM Tta110GrpProduto t WHERE t.numOrder = :numOrder"),
    @NamedQuery(name = "Tta110GrpProduto.findByCdNaBolsa", query = "SELECT t FROM Tta110GrpProduto t WHERE t.cdNaBolsa = :cdNaBolsa"),
    @NamedQuery(name = "Tta110GrpProduto.findByCdParametroSupProd", query = "SELECT t FROM Tta110GrpProduto t WHERE t.cdParametroSupProd = :cdParametroSupProd"),
    @NamedQuery(name = "Tta110GrpProduto.findByCdParametroInfProd", query = "SELECT t FROM Tta110GrpProduto t WHERE t.cdParametroInfProd = :cdParametroInfProd"),
    @NamedQuery(name = "Tta110GrpProduto.findByVlUnidadeMedidaIntegracao", query = "SELECT t FROM Tta110GrpProduto t WHERE t.vlUnidadeMedidaIntegracao = :vlUnidadeMedidaIntegracao"),
    @NamedQuery(name = "Tta110GrpProduto.findByGrpCompradores", query = "SELECT t FROM Tta110GrpProduto t WHERE t.grpCompradores = :grpCompradores"),
    @NamedQuery(name = "Tta110GrpProduto.findByNmGrpPrdIngles", query = "SELECT t FROM Tta110GrpProduto t WHERE t.nmGrpPrdIngles = :nmGrpPrdIngles")})
public class Tta110GrpProduto implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "CD_GRP_PRODUTO")
    private BigDecimal cdGrpProduto;
    @Basic(optional = false)
    @Column(name = "NM_GRP_PRODUTO")
    private String nmGrpProduto;
    @Column(name = "CD_NEGOCIO")
    private Short cdNegocio;
    @Column(name = "UN_MEDIDA")
    private String unMedida;
    @Column(name = "PERCENT_VL_COMISSAO")
    private BigDecimal percentVlComissao;
    @Column(name = "NUM_ORDER")
    private Character numOrder;
    @Column(name = "CD_NA_BOLSA")
    private String cdNaBolsa;
    @Column(name = "CD_PARAMETRO_SUP_PROD")
    private Short cdParametroSupProd;
    @Column(name = "CD_PARAMETRO_INF_PROD")
    private Integer cdParametroInfProd;
    @Column(name = "VL_UNIDADE_MEDIDA_INTEGRACAO")
    private Long vlUnidadeMedidaIntegracao;
    @Column(name = "GRP_COMPRADORES")
    private String grpCompradores;
    @Column(name = "NM_GRP_PRD_INGLES")
    private String nmGrpPrdIngles;
    @JoinColumn(name = "CD_UNIDADE_MEDIDA_INTEGRACAO", referencedColumnName = "CD_UNIDADE_MEDIDA")
    @ManyToOne
    private Txc120UnidadeMedida cdUnidadeMedidaIntegracao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tta110GrpProduto")
    private Collection<Ttv304ValoresMercado> ttv304ValoresMercadoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tta110GrpProduto")
    private Collection<Tta091FatorConvProdutoBols> tta091FatorConvProdutoBolsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tta110GrpProduto")
    private Collection<Tta035BolsaProdutoPeriodo> tta035BolsaProdutoPeriodoCollection;
    @OneToMany(mappedBy = "cdGrpProduto")
    private Collection<Tth002DesignacaoHdr> tth002DesignacaoHdrCollection;

    public Tta110GrpProduto() {
    }

    public Tta110GrpProduto(BigDecimal cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public Tta110GrpProduto(BigDecimal cdGrpProduto, String nmGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
        this.nmGrpProduto = nmGrpProduto;
    }

    public BigDecimal getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(BigDecimal cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    public String getNmGrpProduto() {
        return nmGrpProduto;
    }

    public void setNmGrpProduto(String nmGrpProduto) {
        this.nmGrpProduto = nmGrpProduto;
    }

    public Short getCdNegocio() {
        return cdNegocio;
    }

    public void setCdNegocio(Short cdNegocio) {
        this.cdNegocio = cdNegocio;
    }

    public String getUnMedida() {
        return unMedida;
    }

    public void setUnMedida(String unMedida) {
        this.unMedida = unMedida;
    }

    public BigDecimal getPercentVlComissao() {
        return percentVlComissao;
    }

    public void setPercentVlComissao(BigDecimal percentVlComissao) {
        this.percentVlComissao = percentVlComissao;
    }

    public Character getNumOrder() {
        return numOrder;
    }

    public void setNumOrder(Character numOrder) {
        this.numOrder = numOrder;
    }

    public String getCdNaBolsa() {
        return cdNaBolsa;
    }

    public void setCdNaBolsa(String cdNaBolsa) {
        this.cdNaBolsa = cdNaBolsa;
    }

    public Short getCdParametroSupProd() {
        return cdParametroSupProd;
    }

    public void setCdParametroSupProd(Short cdParametroSupProd) {
        this.cdParametroSupProd = cdParametroSupProd;
    }

    public Integer getCdParametroInfProd() {
        return cdParametroInfProd;
    }

    public void setCdParametroInfProd(Integer cdParametroInfProd) {
        this.cdParametroInfProd = cdParametroInfProd;
    }

    public Long getVlUnidadeMedidaIntegracao() {
        return vlUnidadeMedidaIntegracao;
    }

    public void setVlUnidadeMedidaIntegracao(Long vlUnidadeMedidaIntegracao) {
        this.vlUnidadeMedidaIntegracao = vlUnidadeMedidaIntegracao;
    }

    public String getGrpCompradores() {
        return grpCompradores;
    }

    public void setGrpCompradores(String grpCompradores) {
        this.grpCompradores = grpCompradores;
    }

    public String getNmGrpPrdIngles() {
        return nmGrpPrdIngles;
    }

    public void setNmGrpPrdIngles(String nmGrpPrdIngles) {
        this.nmGrpPrdIngles = nmGrpPrdIngles;
    }

    public Txc120UnidadeMedida getCdUnidadeMedidaIntegracao() {
        return cdUnidadeMedidaIntegracao;
    }

    public void setCdUnidadeMedidaIntegracao(Txc120UnidadeMedida cdUnidadeMedidaIntegracao) {
        this.cdUnidadeMedidaIntegracao = cdUnidadeMedidaIntegracao;
    }

    @XmlTransient
    public Collection<Ttv304ValoresMercado> getTtv304ValoresMercadoCollection() {
        return ttv304ValoresMercadoCollection;
    }

    public void setTtv304ValoresMercadoCollection(Collection<Ttv304ValoresMercado> ttv304ValoresMercadoCollection) {
        this.ttv304ValoresMercadoCollection = ttv304ValoresMercadoCollection;
    }

    @XmlTransient
    public Collection<Tta091FatorConvProdutoBols> getTta091FatorConvProdutoBolsCollection() {
        return tta091FatorConvProdutoBolsCollection;
    }

    public void setTta091FatorConvProdutoBolsCollection(Collection<Tta091FatorConvProdutoBols> tta091FatorConvProdutoBolsCollection) {
        this.tta091FatorConvProdutoBolsCollection = tta091FatorConvProdutoBolsCollection;
    }

    @XmlTransient
    public Collection<Tta035BolsaProdutoPeriodo> getTta035BolsaProdutoPeriodoCollection() {
        return tta035BolsaProdutoPeriodoCollection;
    }

    public void setTta035BolsaProdutoPeriodoCollection(Collection<Tta035BolsaProdutoPeriodo> tta035BolsaProdutoPeriodoCollection) {
        this.tta035BolsaProdutoPeriodoCollection = tta035BolsaProdutoPeriodoCollection;
    }

    @XmlTransient
    public Collection<Tth002DesignacaoHdr> getTth002DesignacaoHdrCollection() {
        return tth002DesignacaoHdrCollection;
    }

    public void setTth002DesignacaoHdrCollection(Collection<Tth002DesignacaoHdr> tth002DesignacaoHdrCollection) {
        this.tth002DesignacaoHdrCollection = tth002DesignacaoHdrCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdGrpProduto != null ? cdGrpProduto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta110GrpProduto)) {
            return false;
        }
        Tta110GrpProduto other = (Tta110GrpProduto) object;
        if ((this.cdGrpProduto == null && other.cdGrpProduto != null) || (this.cdGrpProduto != null && !this.cdGrpProduto.equals(other.cdGrpProduto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta110GrpProduto[ cdGrpProduto=" + cdGrpProduto + " ]";
    }
    
}
