package br.com.bpss.hg.domain;

import java.io.Serializable;

public class GenericDomain implements Serializable {

	private static final long serialVersionUID = -1519438404385956981L;

	
}
