/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA150_J_PARAMETRO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta150JParametro.findAll", query = "SELECT t FROM Tta150JParametro t"),
    @NamedQuery(name = "Tta150JParametro.findBySafra", query = "SELECT t FROM Tta150JParametro t WHERE t.safra = :safra"),
    @NamedQuery(name = "Tta150JParametro.findByStatus", query = "SELECT t FROM Tta150JParametro t WHERE t.status = :status"),
    @NamedQuery(name = "Tta150JParametro.findByDataIni", query = "SELECT t FROM Tta150JParametro t WHERE t.dataIni = :dataIni"),
    @NamedQuery(name = "Tta150JParametro.findByDataFim", query = "SELECT t FROM Tta150JParametro t WHERE t.dataFim = :dataFim"),
    @NamedQuery(name = "Tta150JParametro.findByMesAno", query = "SELECT t FROM Tta150JParametro t WHERE t.mesAno = :mesAno"),
    @NamedQuery(name = "Tta150JParametro.findByStatusCalculo", query = "SELECT t FROM Tta150JParametro t WHERE t.statusCalculo = :statusCalculo"),
    @NamedQuery(name = "Tta150JParametro.findByFlStatusCalculo", query = "SELECT t FROM Tta150JParametro t WHERE t.flStatusCalculo = :flStatusCalculo"),
    @NamedQuery(name = "Tta150JParametro.findByLimiteMinimo", query = "SELECT t FROM Tta150JParametro t WHERE t.limiteMinimo = :limiteMinimo"),
    @NamedQuery(name = "Tta150JParametro.findByLimiteMaximo", query = "SELECT t FROM Tta150JParametro t WHERE t.limiteMaximo = :limiteMaximo"),
    @NamedQuery(name = "Tta150JParametro.findByDtMovimento", query = "SELECT t FROM Tta150JParametro t WHERE t.dtMovimento = :dtMovimento")})
public class Tta150JParametro implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "SAFRA")
    private String safra;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "DATA_INI")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataIni;
    @Column(name = "DATA_FIM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataFim;
    @Column(name = "MES_ANO")
    private String mesAno;
    @Column(name = "STATUS_CALCULO")
    private String statusCalculo;
    @Column(name = "FL_STATUS_CALCULO")
    private Character flStatusCalculo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "LIMITE_MINIMO")
    private BigDecimal limiteMinimo;
    @Column(name = "LIMITE_MAXIMO")
    private BigDecimal limiteMaximo;
    @Column(name = "DT_MOVIMENTO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtMovimento;

    public Tta150JParametro() {
    }

    public String getSafra() {
        return safra;
    }

    public void setSafra(String safra) {
        this.safra = safra;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDataIni() {
        return dataIni;
    }

    public void setDataIni(Date dataIni) {
        this.dataIni = dataIni;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public String getStatusCalculo() {
        return statusCalculo;
    }

    public void setStatusCalculo(String statusCalculo) {
        this.statusCalculo = statusCalculo;
    }

    public Character getFlStatusCalculo() {
        return flStatusCalculo;
    }

    public void setFlStatusCalculo(Character flStatusCalculo) {
        this.flStatusCalculo = flStatusCalculo;
    }

    public BigDecimal getLimiteMinimo() {
        return limiteMinimo;
    }

    public void setLimiteMinimo(BigDecimal limiteMinimo) {
        this.limiteMinimo = limiteMinimo;
    }

    public BigDecimal getLimiteMaximo() {
        return limiteMaximo;
    }

    public void setLimiteMaximo(BigDecimal limiteMaximo) {
        this.limiteMaximo = limiteMaximo;
    }

    public Date getDtMovimento() {
        return dtMovimento;
    }

    public void setDtMovimento(Date dtMovimento) {
        this.dtMovimento = dtMovimento;
    }
    
}
