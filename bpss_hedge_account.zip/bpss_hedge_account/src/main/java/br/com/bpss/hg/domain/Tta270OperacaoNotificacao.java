/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA270_OPERACAO_NOTIFICACAO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta270OperacaoNotificacao.findAll", query = "SELECT t FROM Tta270OperacaoNotificacao t"),
    @NamedQuery(name = "Tta270OperacaoNotificacao.findByCdCodOpe", query = "SELECT t FROM Tta270OperacaoNotificacao t WHERE t.cdCodOpe = :cdCodOpe"),
    @NamedQuery(name = "Tta270OperacaoNotificacao.findByDescOpe", query = "SELECT t FROM Tta270OperacaoNotificacao t WHERE t.descOpe = :descOpe"),
    @NamedQuery(name = "Tta270OperacaoNotificacao.findByFlMsgExc", query = "SELECT t FROM Tta270OperacaoNotificacao t WHERE t.flMsgExc = :flMsgExc"),
    @NamedQuery(name = "Tta270OperacaoNotificacao.findByNotiPadrao", query = "SELECT t FROM Tta270OperacaoNotificacao t WHERE t.notiPadrao = :notiPadrao")})
public class Tta270OperacaoNotificacao implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "CD_COD_OPE")
    private BigDecimal cdCodOpe;
    @Column(name = "DESC_OPE")
    private String descOpe;
    @Column(name = "FL_MSG_EXC")
    private Character flMsgExc;
    @Column(name = "NOTI_PADRAO")
    private Character notiPadrao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tta270OperacaoNotificacao")
    private Collection<Tta275OpeNotifiEmail> tta275OpeNotifiEmailCollection;

    public Tta270OperacaoNotificacao() {
    }

    public Tta270OperacaoNotificacao(BigDecimal cdCodOpe) {
        this.cdCodOpe = cdCodOpe;
    }

    public BigDecimal getCdCodOpe() {
        return cdCodOpe;
    }

    public void setCdCodOpe(BigDecimal cdCodOpe) {
        this.cdCodOpe = cdCodOpe;
    }

    public String getDescOpe() {
        return descOpe;
    }

    public void setDescOpe(String descOpe) {
        this.descOpe = descOpe;
    }

    public Character getFlMsgExc() {
        return flMsgExc;
    }

    public void setFlMsgExc(Character flMsgExc) {
        this.flMsgExc = flMsgExc;
    }

    public Character getNotiPadrao() {
        return notiPadrao;
    }

    public void setNotiPadrao(Character notiPadrao) {
        this.notiPadrao = notiPadrao;
    }

    @XmlTransient
    public Collection<Tta275OpeNotifiEmail> getTta275OpeNotifiEmailCollection() {
        return tta275OpeNotifiEmailCollection;
    }

    public void setTta275OpeNotifiEmailCollection(Collection<Tta275OpeNotifiEmail> tta275OpeNotifiEmailCollection) {
        this.tta275OpeNotifiEmailCollection = tta275OpeNotifiEmailCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdCodOpe != null ? cdCodOpe.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta270OperacaoNotificacao)) {
            return false;
        }
        Tta270OperacaoNotificacao other = (Tta270OperacaoNotificacao) object;
        if ((this.cdCodOpe == null && other.cdCodOpe != null) || (this.cdCodOpe != null && !this.cdCodOpe.equals(other.cdCodOpe))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta270OperacaoNotificacao[ cdCodOpe=" + cdCodOpe + " ]";
    }
    
}
