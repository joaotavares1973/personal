/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class Tta091FatorConvProdutoBolsPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "CD_PRODUTO")
    private int cdProduto;
    @Basic(optional = false)
    @Column(name = "CD_BOLSA")
    private BigInteger cdBolsa;

    public Tta091FatorConvProdutoBolsPK() {
    }

    public Tta091FatorConvProdutoBolsPK(int cdProduto, BigInteger cdBolsa) {
        this.cdProduto = cdProduto;
        this.cdBolsa = cdBolsa;
    }

    public int getCdProduto() {
        return cdProduto;
    }

    public void setCdProduto(int cdProduto) {
        this.cdProduto = cdProduto;
    }

    public BigInteger getCdBolsa() {
        return cdBolsa;
    }

    public void setCdBolsa(BigInteger cdBolsa) {
        this.cdBolsa = cdBolsa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cdProduto;
        hash += (cdBolsa != null ? cdBolsa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta091FatorConvProdutoBolsPK)) {
            return false;
        }
        Tta091FatorConvProdutoBolsPK other = (Tta091FatorConvProdutoBolsPK) object;
        if (this.cdProduto != other.cdProduto) {
            return false;
        }
        if ((this.cdBolsa == null && other.cdBolsa != null) || (this.cdBolsa != null && !this.cdBolsa.equals(other.cdBolsa))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta091FatorConvProdutoBolsPK[ cdProduto=" + cdProduto + ", cdBolsa=" + cdBolsa + " ]";
    }
    
}
