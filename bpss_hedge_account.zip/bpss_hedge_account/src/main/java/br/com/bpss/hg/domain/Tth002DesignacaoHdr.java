/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH002_DESIGNACAO_HDR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth002DesignacaoHdr.findAll", query = "SELECT t FROM Tth002DesignacaoHdr t"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByCdDesignacao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.cdDesignacao = :cdDesignacao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByAnoSafra", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.anoSafra = :anoSafra"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByCdObjetoHedge", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.cdObjetoHedge = :cdObjetoHedge"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByMesAnoAlocacao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.mesAnoAlocacao = :mesAnoAlocacao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByDtAlocacao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.dtAlocacao = :dtAlocacao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByPctEfetividade", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.pctEfetividade = :pctEfetividade"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByStatus", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.status = :status"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByDtLiquidacao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.dtLiquidacao = :dtLiquidacao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByObservacao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.observacao = :observacao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByDhSysInsercao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.dhSysInsercao = :dhSysInsercao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByCdUsuarioInsercao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.cdUsuarioInsercao = :cdUsuarioInsercao"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByCdUsuarioRevisor", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.cdUsuarioRevisor = :cdUsuarioRevisor"),
    @NamedQuery(name = "Tth002DesignacaoHdr.findByDhSysRevisao", query = "SELECT t FROM Tth002DesignacaoHdr t WHERE t.dhSysRevisao = :dhSysRevisao")})
public class Tth002DesignacaoHdr implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_DESIGNACAO")
    private Long cdDesignacao;
    @Column(name = "ANO_SAFRA")
    private String anoSafra;
    @Column(name = "CD_OBJETO_HEDGE")
    private String cdObjetoHedge;
    @Column(name = "MES_ANO_ALOCACAO")
    private String mesAnoAlocacao;
    @Column(name = "DT_ALOCACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtAlocacao;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PCT_EFETIVIDADE")
    private BigDecimal pctEfetividade;
    @Column(name = "STATUS")
    private Character status;
    @Column(name = "DT_LIQUIDACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dtLiquidacao;
    @Column(name = "OBSERVACAO")
    private String observacao;
    @Column(name = "DH_SYS_INSERCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysInsercao;
    @Column(name = "CD_USUARIO_INSERCAO")
    private String cdUsuarioInsercao;
    @Column(name = "CD_USUARIO_REVISOR")
    private String cdUsuarioRevisor;
    @Column(name = "DH_SYS_REVISAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysRevisao;
    @JoinColumn(name = "CD_TIPO_INSTRUMENTO", referencedColumnName = "CD_TIPO_INSTRUMENTO")
    @ManyToOne
    private Ttv303TipoInstrumento cdTipoInstrumento;
    @JoinColumn(name = "CD_TIPO_CONTABILIDADE", referencedColumnName = "CD_TIPO_CONTABILIDADE")
    @ManyToOne
    private Ttv302TipoContabilidade cdTipoContabilidade;
    @JoinColumn(name = "CD_GRP_PRODUTO", referencedColumnName = "CD_GRP_PRODUTO")
    @ManyToOne
    private Tta110GrpProduto cdGrpProduto;

    public Tth002DesignacaoHdr() {
    }

    public Tth002DesignacaoHdr(Long cdDesignacao) {
        this.cdDesignacao = cdDesignacao;
    }

    public Long getCdDesignacao() {
        return cdDesignacao;
    }

    public void setCdDesignacao(Long cdDesignacao) {
        this.cdDesignacao = cdDesignacao;
    }

    public String getAnoSafra() {
        return anoSafra;
    }

    public void setAnoSafra(String anoSafra) {
        this.anoSafra = anoSafra;
    }

    public String getCdObjetoHedge() {
        return cdObjetoHedge;
    }

    public void setCdObjetoHedge(String cdObjetoHedge) {
        this.cdObjetoHedge = cdObjetoHedge;
    }

    public String getMesAnoAlocacao() {
        return mesAnoAlocacao;
    }

    public void setMesAnoAlocacao(String mesAnoAlocacao) {
        this.mesAnoAlocacao = mesAnoAlocacao;
    }

    public Date getDtAlocacao() {
        return dtAlocacao;
    }

    public void setDtAlocacao(Date dtAlocacao) {
        this.dtAlocacao = dtAlocacao;
    }

    public BigDecimal getPctEfetividade() {
        return pctEfetividade;
    }

    public void setPctEfetividade(BigDecimal pctEfetividade) {
        this.pctEfetividade = pctEfetividade;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public Date getDtLiquidacao() {
        return dtLiquidacao;
    }

    public void setDtLiquidacao(Date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Date getDhSysInsercao() {
        return dhSysInsercao;
    }

    public void setDhSysInsercao(Date dhSysInsercao) {
        this.dhSysInsercao = dhSysInsercao;
    }

    public String getCdUsuarioInsercao() {
        return cdUsuarioInsercao;
    }

    public void setCdUsuarioInsercao(String cdUsuarioInsercao) {
        this.cdUsuarioInsercao = cdUsuarioInsercao;
    }

    public String getCdUsuarioRevisor() {
        return cdUsuarioRevisor;
    }

    public void setCdUsuarioRevisor(String cdUsuarioRevisor) {
        this.cdUsuarioRevisor = cdUsuarioRevisor;
    }

    public Date getDhSysRevisao() {
        return dhSysRevisao;
    }

    public void setDhSysRevisao(Date dhSysRevisao) {
        this.dhSysRevisao = dhSysRevisao;
    }

    public Ttv303TipoInstrumento getCdTipoInstrumento() {
        return cdTipoInstrumento;
    }

    public void setCdTipoInstrumento(Ttv303TipoInstrumento cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    public Ttv302TipoContabilidade getCdTipoContabilidade() {
        return cdTipoContabilidade;
    }

    public void setCdTipoContabilidade(Ttv302TipoContabilidade cdTipoContabilidade) {
        this.cdTipoContabilidade = cdTipoContabilidade;
    }

    public Tta110GrpProduto getCdGrpProduto() {
        return cdGrpProduto;
    }

    public void setCdGrpProduto(Tta110GrpProduto cdGrpProduto) {
        this.cdGrpProduto = cdGrpProduto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdDesignacao != null ? cdDesignacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tth002DesignacaoHdr)) {
            return false;
        }
        Tth002DesignacaoHdr other = (Tth002DesignacaoHdr) object;
        if ((this.cdDesignacao == null && other.cdDesignacao != null) || (this.cdDesignacao != null && !this.cdDesignacao.equals(other.cdDesignacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tth002DesignacaoHdr[ cdDesignacao=" + cdDesignacao + " ]";
    }
    
}
