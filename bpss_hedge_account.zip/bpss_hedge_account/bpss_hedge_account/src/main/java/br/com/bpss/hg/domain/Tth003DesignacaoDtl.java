/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH003_DESIGNACAO_DTL")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth003DesignacaoDtl.findAll", query = "SELECT t FROM Tth003DesignacaoDtl t"),
    @NamedQuery(name = "Tth003DesignacaoDtl.findByCdDesignacao", query = "SELECT t FROM Tth003DesignacaoDtl t WHERE t.tth003DesignacaoDtlPK.cdDesignacao = :cdDesignacao"),
    @NamedQuery(name = "Tth003DesignacaoDtl.findByCdOperacao", query = "SELECT t FROM Tth003DesignacaoDtl t WHERE t.tth003DesignacaoDtlPK.cdOperacao = :cdOperacao"),
    @NamedQuery(name = "Tth003DesignacaoDtl.findByQtdeRolada", query = "SELECT t FROM Tth003DesignacaoDtl t WHERE t.qtdeRolada = :qtdeRolada"),
    @NamedQuery(name = "Tth003DesignacaoDtl.findByDhSysInsercao", query = "SELECT t FROM Tth003DesignacaoDtl t WHERE t.dhSysInsercao = :dhSysInsercao"),
    @NamedQuery(name = "Tth003DesignacaoDtl.findByCdUsuarioInsercao", query = "SELECT t FROM Tth003DesignacaoDtl t WHERE t.cdUsuarioInsercao = :cdUsuarioInsercao")})
public class Tth003DesignacaoDtl implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tth003DesignacaoDtlPK tth003DesignacaoDtlPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "QTDE_ROLADA")
    private BigDecimal qtdeRolada;
    @Column(name = "DH_SYS_INSERCAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhSysInsercao;
    @Column(name = "CD_USUARIO_INSERCAO")
    private String cdUsuarioInsercao;
    @JoinColumn(name = "CD_OPERACAO", referencedColumnName = "CD_OPERACAO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tth001Operacoes tth001Operacoes;

    public Tth003DesignacaoDtl() {
    }

    public Tth003DesignacaoDtl(Tth003DesignacaoDtlPK tth003DesignacaoDtlPK) {
        this.tth003DesignacaoDtlPK = tth003DesignacaoDtlPK;
    }

    public Tth003DesignacaoDtl(long cdDesignacao, long cdOperacao) {
        this.tth003DesignacaoDtlPK = new Tth003DesignacaoDtlPK(cdDesignacao, cdOperacao);
    }

    public Tth003DesignacaoDtlPK getTth003DesignacaoDtlPK() {
        return tth003DesignacaoDtlPK;
    }

    public void setTth003DesignacaoDtlPK(Tth003DesignacaoDtlPK tth003DesignacaoDtlPK) {
        this.tth003DesignacaoDtlPK = tth003DesignacaoDtlPK;
    }

    public BigDecimal getQtdeRolada() {
        return qtdeRolada;
    }

    public void setQtdeRolada(BigDecimal qtdeRolada) {
        this.qtdeRolada = qtdeRolada;
    }

    public Date getDhSysInsercao() {
        return dhSysInsercao;
    }

    public void setDhSysInsercao(Date dhSysInsercao) {
        this.dhSysInsercao = dhSysInsercao;
    }

    public String getCdUsuarioInsercao() {
        return cdUsuarioInsercao;
    }

    public void setCdUsuarioInsercao(String cdUsuarioInsercao) {
        this.cdUsuarioInsercao = cdUsuarioInsercao;
    }

    public Tth001Operacoes getTth001Operacoes() {
        return tth001Operacoes;
    }

    public void setTth001Operacoes(Tth001Operacoes tth001Operacoes) {
        this.tth001Operacoes = tth001Operacoes;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tth003DesignacaoDtlPK != null ? tth003DesignacaoDtlPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tth003DesignacaoDtl)) {
            return false;
        }
        Tth003DesignacaoDtl other = (Tth003DesignacaoDtl) object;
        if ((this.tth003DesignacaoDtlPK == null && other.tth003DesignacaoDtlPK != null) || (this.tth003DesignacaoDtlPK != null && !this.tth003DesignacaoDtlPK.equals(other.tth003DesignacaoDtlPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tth003DesignacaoDtl[ tth003DesignacaoDtlPK=" + tth003DesignacaoDtlPK + " ]";
    }
    
}
