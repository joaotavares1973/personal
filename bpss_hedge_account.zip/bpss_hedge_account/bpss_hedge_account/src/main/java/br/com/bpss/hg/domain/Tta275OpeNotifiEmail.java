/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA275_OPE_NOTIFI_EMAIL")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta275OpeNotifiEmail.findAll", query = "SELECT t FROM Tta275OpeNotifiEmail t"),
    @NamedQuery(name = "Tta275OpeNotifiEmail.findByCdCodOpe", query = "SELECT t FROM Tta275OpeNotifiEmail t WHERE t.tta275OpeNotifiEmailPK.cdCodOpe = :cdCodOpe"),
    @NamedQuery(name = "Tta275OpeNotifiEmail.findByCdCodEmail", query = "SELECT t FROM Tta275OpeNotifiEmail t WHERE t.tta275OpeNotifiEmailPK.cdCodEmail = :cdCodEmail"),
    @NamedQuery(name = "Tta275OpeNotifiEmail.findByEmailUsu", query = "SELECT t FROM Tta275OpeNotifiEmail t WHERE t.emailUsu = :emailUsu")})
public class Tta275OpeNotifiEmail implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tta275OpeNotifiEmailPK tta275OpeNotifiEmailPK;
    @Column(name = "EMAIL_USU")
    private String emailUsu;
    @JoinColumn(name = "CD_COD_OPE", referencedColumnName = "CD_COD_OPE", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Tta270OperacaoNotificacao tta270OperacaoNotificacao;

    public Tta275OpeNotifiEmail() {
    }

    public Tta275OpeNotifiEmail(Tta275OpeNotifiEmailPK tta275OpeNotifiEmailPK) {
        this.tta275OpeNotifiEmailPK = tta275OpeNotifiEmailPK;
    }

    public Tta275OpeNotifiEmail(BigInteger cdCodOpe, BigInteger cdCodEmail) {
        this.tta275OpeNotifiEmailPK = new Tta275OpeNotifiEmailPK(cdCodOpe, cdCodEmail);
    }

    public Tta275OpeNotifiEmailPK getTta275OpeNotifiEmailPK() {
        return tta275OpeNotifiEmailPK;
    }

    public void setTta275OpeNotifiEmailPK(Tta275OpeNotifiEmailPK tta275OpeNotifiEmailPK) {
        this.tta275OpeNotifiEmailPK = tta275OpeNotifiEmailPK;
    }

    public String getEmailUsu() {
        return emailUsu;
    }

    public void setEmailUsu(String emailUsu) {
        this.emailUsu = emailUsu;
    }

    public Tta270OperacaoNotificacao getTta270OperacaoNotificacao() {
        return tta270OperacaoNotificacao;
    }

    public void setTta270OperacaoNotificacao(Tta270OperacaoNotificacao tta270OperacaoNotificacao) {
        this.tta270OperacaoNotificacao = tta270OperacaoNotificacao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tta275OpeNotifiEmailPK != null ? tta275OpeNotifiEmailPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta275OpeNotifiEmail)) {
            return false;
        }
        Tta275OpeNotifiEmail other = (Tta275OpeNotifiEmail) object;
        if ((this.tta275OpeNotifiEmailPK == null && other.tta275OpeNotifiEmailPK != null) || (this.tta275OpeNotifiEmailPK != null && !this.tta275OpeNotifiEmailPK.equals(other.tta275OpeNotifiEmailPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta275OpeNotifiEmail[ tta275OpeNotifiEmailPK=" + tta275OpeNotifiEmailPK + " ]";
    }
    
}
