/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH005_CALCULOS_DTL")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth005CalculosDtl.findAll", query = "SELECT t FROM Tth005CalculosDtl t"),
    @NamedQuery(name = "Tth005CalculosDtl.findByCdCalculo", query = "SELECT t FROM Tth005CalculosDtl t WHERE t.tth005CalculosDtlPK.cdCalculo = :cdCalculo"),
    @NamedQuery(name = "Tth005CalculosDtl.findByCdDesignacao", query = "SELECT t FROM Tth005CalculosDtl t WHERE t.tth005CalculosDtlPK.cdDesignacao = :cdDesignacao"),
    @NamedQuery(name = "Tth005CalculosDtl.findByCdOperacao", query = "SELECT t FROM Tth005CalculosDtl t WHERE t.tth005CalculosDtlPK.cdOperacao = :cdOperacao"),
    @NamedQuery(name = "Tth005CalculosDtl.findByVlrMercado", query = "SELECT t FROM Tth005CalculosDtl t WHERE t.vlrMercado = :vlrMercado"),
    @NamedQuery(name = "Tth005CalculosDtl.findByVlrAjuste", query = "SELECT t FROM Tth005CalculosDtl t WHERE t.vlrAjuste = :vlrAjuste")})
public class Tth005CalculosDtl implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected Tth005CalculosDtlPK tth005CalculosDtlPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "VLR_MERCADO")
    private BigDecimal vlrMercado;
    @Column(name = "VLR_AJUSTE")
    private BigDecimal vlrAjuste;

    public Tth005CalculosDtl() {
    }

    public Tth005CalculosDtl(Tth005CalculosDtlPK tth005CalculosDtlPK) {
        this.tth005CalculosDtlPK = tth005CalculosDtlPK;
    }

    public Tth005CalculosDtl(long cdCalculo, long cdDesignacao, long cdOperacao) {
        this.tth005CalculosDtlPK = new Tth005CalculosDtlPK(cdCalculo, cdDesignacao, cdOperacao);
    }

    public Tth005CalculosDtlPK getTth005CalculosDtlPK() {
        return tth005CalculosDtlPK;
    }

    public void setTth005CalculosDtlPK(Tth005CalculosDtlPK tth005CalculosDtlPK) {
        this.tth005CalculosDtlPK = tth005CalculosDtlPK;
    }

    public BigDecimal getVlrMercado() {
        return vlrMercado;
    }

    public void setVlrMercado(BigDecimal vlrMercado) {
        this.vlrMercado = vlrMercado;
    }

    public BigDecimal getVlrAjuste() {
        return vlrAjuste;
    }

    public void setVlrAjuste(BigDecimal vlrAjuste) {
        this.vlrAjuste = vlrAjuste;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tth005CalculosDtlPK != null ? tth005CalculosDtlPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tth005CalculosDtl)) {
            return false;
        }
        Tth005CalculosDtl other = (Tth005CalculosDtl) object;
        if ((this.tth005CalculosDtlPK == null && other.tth005CalculosDtlPK != null) || (this.tth005CalculosDtlPK != null && !this.tth005CalculosDtlPK.equals(other.tth005CalculosDtlPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tth005CalculosDtl[ tth005CalculosDtlPK=" + tth005CalculosDtlPK + " ]";
    }
    
}
