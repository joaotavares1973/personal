/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV302_TIPO_CONTABILIDADE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv302TipoContabilidade.findAll", query = "SELECT t FROM Ttv302TipoContabilidade t"),
    @NamedQuery(name = "Ttv302TipoContabilidade.findByCdTipoContabilidade", query = "SELECT t FROM Ttv302TipoContabilidade t WHERE t.cdTipoContabilidade = :cdTipoContabilidade"),
    @NamedQuery(name = "Ttv302TipoContabilidade.findByDsTipoContabilidade", query = "SELECT t FROM Ttv302TipoContabilidade t WHERE t.dsTipoContabilidade = :dsTipoContabilidade")})
public class Ttv302TipoContabilidade implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "CD_TIPO_CONTABILIDADE")
    private BigDecimal cdTipoContabilidade;
    @Basic(optional = false)
    @Column(name = "DS_TIPO_CONTABILIDADE")
    private String dsTipoContabilidade;
    @OneToMany(mappedBy = "cdTipoContabilidade")
    private Collection<Tth002DesignacaoHdr> tth002DesignacaoHdrCollection;

    public Ttv302TipoContabilidade() {
    }

    public Ttv302TipoContabilidade(BigDecimal cdTipoContabilidade) {
        this.cdTipoContabilidade = cdTipoContabilidade;
    }

    public Ttv302TipoContabilidade(BigDecimal cdTipoContabilidade, String dsTipoContabilidade) {
        this.cdTipoContabilidade = cdTipoContabilidade;
        this.dsTipoContabilidade = dsTipoContabilidade;
    }

    public BigDecimal getCdTipoContabilidade() {
        return cdTipoContabilidade;
    }

    public void setCdTipoContabilidade(BigDecimal cdTipoContabilidade) {
        this.cdTipoContabilidade = cdTipoContabilidade;
    }

    public String getDsTipoContabilidade() {
        return dsTipoContabilidade;
    }

    public void setDsTipoContabilidade(String dsTipoContabilidade) {
        this.dsTipoContabilidade = dsTipoContabilidade;
    }

    @XmlTransient
    public Collection<Tth002DesignacaoHdr> getTth002DesignacaoHdrCollection() {
        return tth002DesignacaoHdrCollection;
    }

    public void setTth002DesignacaoHdrCollection(Collection<Tth002DesignacaoHdr> tth002DesignacaoHdrCollection) {
        this.tth002DesignacaoHdrCollection = tth002DesignacaoHdrCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdTipoContabilidade != null ? cdTipoContabilidade.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ttv302TipoContabilidade)) {
            return false;
        }
        Ttv302TipoContabilidade other = (Ttv302TipoContabilidade) object;
        if ((this.cdTipoContabilidade == null && other.cdTipoContabilidade != null) || (this.cdTipoContabilidade != null && !this.cdTipoContabilidade.equals(other.cdTipoContabilidade))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Ttv302TipoContabilidade[ cdTipoContabilidade=" + cdTipoContabilidade + " ]";
    }
    
}
