/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TXC120_UNIDADE_MEDIDA")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Txc120UnidadeMedida.findAll", query = "SELECT t FROM Txc120UnidadeMedida t"),
    @NamedQuery(name = "Txc120UnidadeMedida.findByCdUnidadeMedida", query = "SELECT t FROM Txc120UnidadeMedida t WHERE t.cdUnidadeMedida = :cdUnidadeMedida"),
    @NamedQuery(name = "Txc120UnidadeMedida.findByCdUnidadeFiscal", query = "SELECT t FROM Txc120UnidadeMedida t WHERE t.cdUnidadeFiscal = :cdUnidadeFiscal"),
    @NamedQuery(name = "Txc120UnidadeMedida.findByDsUnidadeMedida", query = "SELECT t FROM Txc120UnidadeMedida t WHERE t.dsUnidadeMedida = :dsUnidadeMedida"),
    @NamedQuery(name = "Txc120UnidadeMedida.findByStUnidadeMedida", query = "SELECT t FROM Txc120UnidadeMedida t WHERE t.stUnidadeMedida = :stUnidadeMedida")})
public class Txc120UnidadeMedida implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_UNIDADE_MEDIDA")
    private String cdUnidadeMedida;
    @Column(name = "CD_UNIDADE_FISCAL")
    private String cdUnidadeFiscal;
    @Basic(optional = false)
    @Column(name = "DS_UNIDADE_MEDIDA")
    private String dsUnidadeMedida;
    @Column(name = "ST_UNIDADE_MEDIDA")
    private String stUnidadeMedida;
    @OneToMany(mappedBy = "cdUnidadeMedidaIntegracao")
    private Collection<Tta110GrpProduto> tta110GrpProdutoCollection;

    public Txc120UnidadeMedida() {
    }

    public Txc120UnidadeMedida(String cdUnidadeMedida) {
        this.cdUnidadeMedida = cdUnidadeMedida;
    }

    public Txc120UnidadeMedida(String cdUnidadeMedida, String dsUnidadeMedida) {
        this.cdUnidadeMedida = cdUnidadeMedida;
        this.dsUnidadeMedida = dsUnidadeMedida;
    }

    public String getCdUnidadeMedida() {
        return cdUnidadeMedida;
    }

    public void setCdUnidadeMedida(String cdUnidadeMedida) {
        this.cdUnidadeMedida = cdUnidadeMedida;
    }

    public String getCdUnidadeFiscal() {
        return cdUnidadeFiscal;
    }

    public void setCdUnidadeFiscal(String cdUnidadeFiscal) {
        this.cdUnidadeFiscal = cdUnidadeFiscal;
    }

    public String getDsUnidadeMedida() {
        return dsUnidadeMedida;
    }

    public void setDsUnidadeMedida(String dsUnidadeMedida) {
        this.dsUnidadeMedida = dsUnidadeMedida;
    }

    public String getStUnidadeMedida() {
        return stUnidadeMedida;
    }

    public void setStUnidadeMedida(String stUnidadeMedida) {
        this.stUnidadeMedida = stUnidadeMedida;
    }

    @XmlTransient
    public Collection<Tta110GrpProduto> getTta110GrpProdutoCollection() {
        return tta110GrpProdutoCollection;
    }

    public void setTta110GrpProdutoCollection(Collection<Tta110GrpProduto> tta110GrpProdutoCollection) {
        this.tta110GrpProdutoCollection = tta110GrpProdutoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdUnidadeMedida != null ? cdUnidadeMedida.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Txc120UnidadeMedida)) {
            return false;
        }
        Txc120UnidadeMedida other = (Txc120UnidadeMedida) object;
        if ((this.cdUnidadeMedida == null && other.cdUnidadeMedida != null) || (this.cdUnidadeMedida != null && !this.cdUnidadeMedida.equals(other.cdUnidadeMedida))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Txc120UnidadeMedida[ cdUnidadeMedida=" + cdUnidadeMedida + " ]";
    }
    
}
