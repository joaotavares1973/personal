/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTH004_J_LISTA_CALCULOS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tth004JListaCalculos.findAll", query = "SELECT t FROM Tth004JListaCalculos t"),
    @NamedQuery(name = "Tth004JListaCalculos.findByCdCalculo", query = "SELECT t FROM Tth004JListaCalculos t WHERE t.cdCalculo = :cdCalculo"),
    @NamedQuery(name = "Tth004JListaCalculos.findByMesAno", query = "SELECT t FROM Tth004JListaCalculos t WHERE t.mesAno = :mesAno"),
    @NamedQuery(name = "Tth004JListaCalculos.findByDsTipoInstrumento", query = "SELECT t FROM Tth004JListaCalculos t WHERE t.dsTipoInstrumento = :dsTipoInstrumento"),
    @NamedQuery(name = "Tth004JListaCalculos.findByVlAjuste", query = "SELECT t FROM Tth004JListaCalculos t WHERE t.vlAjuste = :vlAjuste")})
public class Tth004JListaCalculos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_CALCULO")
    private long cdCalculo;
    @Column(name = "MES_ANO")
    private String mesAno;
    @Column(name = "DS_TIPO_INSTRUMENTO")
    private String dsTipoInstrumento;
    @Column(name = "VL_AJUSTE")
    private BigInteger vlAjuste;

    public Tth004JListaCalculos() {
    }

    public long getCdCalculo() {
        return cdCalculo;
    }

    public void setCdCalculo(long cdCalculo) {
        this.cdCalculo = cdCalculo;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public String getDsTipoInstrumento() {
        return dsTipoInstrumento;
    }

    public void setDsTipoInstrumento(String dsTipoInstrumento) {
        this.dsTipoInstrumento = dsTipoInstrumento;
    }

    public BigInteger getVlAjuste() {
        return vlAjuste;
    }

    public void setVlAjuste(BigInteger vlAjuste) {
        this.vlAjuste = vlAjuste;
    }
    
}
