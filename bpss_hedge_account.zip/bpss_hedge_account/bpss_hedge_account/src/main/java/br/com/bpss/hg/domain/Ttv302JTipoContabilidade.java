/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV302_J_TIPO_CONTABILIDADE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv302JTipoContabilidade.findAll", query = "SELECT t FROM Ttv302JTipoContabilidade t"),
    @NamedQuery(name = "Ttv302JTipoContabilidade.findByCdTipoContabilidade", query = "SELECT t FROM Ttv302JTipoContabilidade t WHERE t.cdTipoContabilidade = :cdTipoContabilidade"),
    @NamedQuery(name = "Ttv302JTipoContabilidade.findByDsTipoContabilidade", query = "SELECT t FROM Ttv302JTipoContabilidade t WHERE t.dsTipoContabilidade = :dsTipoContabilidade")})
public class Ttv302JTipoContabilidade implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_TIPO_CONTABILIDADE")
    private BigInteger cdTipoContabilidade;
    @Basic(optional = false)
    @Column(name = "DS_TIPO_CONTABILIDADE")
    private String dsTipoContabilidade;

    public Ttv302JTipoContabilidade() {
    }

    public BigInteger getCdTipoContabilidade() {
        return cdTipoContabilidade;
    }

    public void setCdTipoContabilidade(BigInteger cdTipoContabilidade) {
        this.cdTipoContabilidade = cdTipoContabilidade;
    }

    public String getDsTipoContabilidade() {
        return dsTipoContabilidade;
    }

    public void setDsTipoContabilidade(String dsTipoContabilidade) {
        this.dsTipoContabilidade = dsTipoContabilidade;
    }
    
}
