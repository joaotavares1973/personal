/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTV303_J_TIPO_INSTRUMENTO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ttv303JTipoInstrumento.findAll", query = "SELECT t FROM Ttv303JTipoInstrumento t"),
    @NamedQuery(name = "Ttv303JTipoInstrumento.findByCdTipoInstrumento", query = "SELECT t FROM Ttv303JTipoInstrumento t WHERE t.cdTipoInstrumento = :cdTipoInstrumento"),
    @NamedQuery(name = "Ttv303JTipoInstrumento.findByDsTipoInstrumento", query = "SELECT t FROM Ttv303JTipoInstrumento t WHERE t.dsTipoInstrumento = :dsTipoInstrumento")})
public class Ttv303JTipoInstrumento implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CD_TIPO_INSTRUMENTO")
    private BigInteger cdTipoInstrumento;
    @Column(name = "DS_TIPO_INSTRUMENTO")
    private String dsTipoInstrumento;

    public Ttv303JTipoInstrumento() {
    }

    public BigInteger getCdTipoInstrumento() {
        return cdTipoInstrumento;
    }

    public void setCdTipoInstrumento(BigInteger cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    public String getDsTipoInstrumento() {
        return dsTipoInstrumento;
    }

    public void setDsTipoInstrumento(String dsTipoInstrumento) {
        this.dsTipoInstrumento = dsTipoInstrumento;
    }
    
}
