/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bpss.hg.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "TTA104_FIXACAO_TIPO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tta104FixacaoTipo.findAll", query = "SELECT t FROM Tta104FixacaoTipo t"),
    @NamedQuery(name = "Tta104FixacaoTipo.findByCdFixacaoTipo", query = "SELECT t FROM Tta104FixacaoTipo t WHERE t.cdFixacaoTipo = :cdFixacaoTipo"),
    @NamedQuery(name = "Tta104FixacaoTipo.findByNmFixacaoTipo", query = "SELECT t FROM Tta104FixacaoTipo t WHERE t.nmFixacaoTipo = :nmFixacaoTipo"),
    @NamedQuery(name = "Tta104FixacaoTipo.findByFlMostraTela", query = "SELECT t FROM Tta104FixacaoTipo t WHERE t.flMostraTela = :flMostraTela")})
public class Tta104FixacaoTipo implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "CD_FIXACAO_TIPO")
    private BigDecimal cdFixacaoTipo;
    @Basic(optional = false)
    @Column(name = "NM_FIXACAO_TIPO")
    private String nmFixacaoTipo;
    @Column(name = "FL_MOSTRA_TELA")
    private String flMostraTela;
    @JoinColumn(name = "CD_TIPO_INSTRUMENTO", referencedColumnName = "CD_TIPO_INSTRUMENTO")
    @ManyToOne
    private Ttv303TipoInstrumento cdTipoInstrumento;

    public Tta104FixacaoTipo() {
    }

    public Tta104FixacaoTipo(BigDecimal cdFixacaoTipo) {
        this.cdFixacaoTipo = cdFixacaoTipo;
    }

    public Tta104FixacaoTipo(BigDecimal cdFixacaoTipo, String nmFixacaoTipo) {
        this.cdFixacaoTipo = cdFixacaoTipo;
        this.nmFixacaoTipo = nmFixacaoTipo;
    }

    public BigDecimal getCdFixacaoTipo() {
        return cdFixacaoTipo;
    }

    public void setCdFixacaoTipo(BigDecimal cdFixacaoTipo) {
        this.cdFixacaoTipo = cdFixacaoTipo;
    }

    public String getNmFixacaoTipo() {
        return nmFixacaoTipo;
    }

    public void setNmFixacaoTipo(String nmFixacaoTipo) {
        this.nmFixacaoTipo = nmFixacaoTipo;
    }

    public String getFlMostraTela() {
        return flMostraTela;
    }

    public void setFlMostraTela(String flMostraTela) {
        this.flMostraTela = flMostraTela;
    }

    public Ttv303TipoInstrumento getCdTipoInstrumento() {
        return cdTipoInstrumento;
    }

    public void setCdTipoInstrumento(Ttv303TipoInstrumento cdTipoInstrumento) {
        this.cdTipoInstrumento = cdTipoInstrumento;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cdFixacaoTipo != null ? cdFixacaoTipo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tta104FixacaoTipo)) {
            return false;
        }
        Tta104FixacaoTipo other = (Tta104FixacaoTipo) object;
        if ((this.cdFixacaoTipo == null && other.cdFixacaoTipo != null) || (this.cdFixacaoTipo != null && !this.cdFixacaoTipo.equals(other.cdFixacaoTipo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Tta104FixacaoTipo[ cdFixacaoTipo=" + cdFixacaoTipo + " ]";
    }
    
}
